// TOWER_HUNTER_ME210_PROJECT_2019 v0.7
// Author: Team 24 (Zhongnan Hu, Zhe Huang, Arthur Ji, Lucas Zhou)
// Date: 03/07/19

// v0.1
// Constructed the framework for tower hunter.
// Added states including STOP, FORWARD, BACKWARD, LEFT, RIGHT.
// Set up pins for controlling the motors used for robot translation motion.
// Wrote test functions by using keypress.

// v0.2
// Set up all pins according to the electrical design.
// Added ultrasonic sensor code which replaces delay() with IntervalTimer functions.
// Proposed nested state architectures and introduced LAUNCH_STATE, SHOOT_CASTERLY_ROCK_STATE, SHOOT_DRAGONSTONE_STATE, END_STATE

// v0.3
// Fixed a bug in the ultrasonic sensor function printDist().
// Added LA_EN line in function handleStop().
// Added LAUNCH_STATE and END_STATE into the finite state machine.

// v0.4
// Change IntervalTimer to MetroTimer
// Try to fix the direction of the LR driving motors

// v0.5
// Copied the SHOOT_KINGS_LANDING_STATE test from Tower_Hunter_Functionality_Test v0.7

// v0.6
// Added move right after loading

// v0.7
// Delete Casterly Rock State


//////////////////////////////King's Landing Test///////////////////////////////////

#include <Arduino.h>
#include <Metro.h>
#include <Servo.h>

/*---------------Module Defines-----------------------------*/
#define SERVO 0

#define FB_D1 1
#define FB_D2 2
#define FB_EN 3

#define LR_D1 7
#define LR_D2 8
#define LR_EN 9

#define LA_EN 10
#define LA_D1 11
#define LA_D2 12

#define US1_TRIG 13
#define US2_TRIG 14
#define US3_TRIG 15
#define US4_TRIG 16

#define US1_ECHO 18
#define US2_ECHO 19
#define US3_ECHO 20
#define US4_ECHO 21

// #define testMotorPWM 150
#define testMotorPWM 255

// The sensor is triggered by a HIGH pulse of 10 or more microseconds.
// Give a short LOW pulse beforehand to ensure a clean HIGH pulse.
#define TRIG_LOW_PERIOD 5 // 5 microseconds
#define TRIG_HIGH_PERIOD 10 // 10 microseconds
#define PRINT_DIST_PERIOD 250000 // 500000 microseconds -> 0.5 s
#define MEASURE_DIST_PERIOD 250 // print the distances every 250 milliseconds

// competition period 2 min 10 sec -> 130 sec -> 130,000 milliseconds
#define GAME_PERIOD 130000

//loading period: 4 sec -> 4,000 milliseconds
#define LOADING_PERIOD 4000

// the distance which is equivalent to the robot hitting the wall
#define HIT_WALL_DIST 5 // 5 cm


#define MOVING_FOWARD_PERIOD 3000 // for hard coding test only
#define SHOOTING_PERIOD 6000 // after shooting period the servo will be turned off
#define MOVING_BACKWARD_PERIOD 3000 // for hard coding test only
#define SERVO_TURNED_ON_PERIOD 2000 // wait until shooting motor is at high speed

#define SHOOTING_MOTOR_PWM 255
#define SERVO_ON_ANGLE 150
#define SERVO_OFF_ANGLE 180

#define MOVING_BACKWARD_PERIOD_LAUNCH 2000 // for hard coding test only
#define MOVING_LEFT_PERIOD_LAUNCH 9000 // for hard coding test only

#define CALIBRATION_PERIOD 2000 // move for an extra time after touching the wall

#define KINGS_LANDING_TO_RIGHT_DISTANCE 120 // 4ft -> 120 cm approximately
#define SAFE_CLOSE_DISTANCE 10 // 10cm, not hit the wall but close enough to the wall
/*---------------Module Function Prototypes-----------------*/
void checkGlobalEvents(void);
unsigned char TestForKey(void);
void RespToKey(void);

void handleMoveForward(void);
void handleMoveBackward(void);
void handleMoveLeft(void);
void handleMoveRight(void);
void handleStop(void);

// finite state machine service functions
void endGame(void);

void fsmInLaunchState(void);
uint8_t TestForLaunchStateEnd(void);
void RespToLaunchStateEnd(void);

void fsmInShootKingsLandingState(void);
uint8_t TestForShootKingsLandingStateEnd(void);
void RespToShootKingsLandingStateEnd(void);

//loading functions
void handleLoad(void);

// test for hitting walls
uint8_t TestForHitLeftWall(void);
uint8_t TestForHitRightWall(void);
uint8_t TestForHitFrontWall(void);
uint8_t TestForHitBackWall(void);

//ultrasonic sensors
void printDist(void);

/*---------------State Definitions--------------------------*/
typedef enum {
  STATE_STOP, STATE_MOVE_FORWARD, STATE_MOVE_BACKWARD, STATE_MOVE_LEFT, STATE_MOVE_RIGHT, STATE_LOAD, STATE_SHOOT // shooting, loading state not added
} States_basic;

typedef enum {
  LAUNCH_STATE, SHOOT_KINGS_LANDING_STATE, END_STATE
} States_group;


class SuperSonicSensor
{
	unsigned long measure_interval;
	int trig_pin;
	int echo_pin;

	unsigned long previousMillis;

public:
	SuperSonicSensor(unsigned long interval, int trig, int echo){
		measure_interval = interval;
		trig_pin = trig;
		echo_pin = echo;
		pinMode(trig_pin, OUTPUT);
		pinMode(echo_pin, INPUT);

		previousMillis = 0;
	}

  	long distance;

	void UpdateMeasure(){
		unsigned long currentMillis = millis();
		if (currentMillis - previousMillis >= measure_interval){
			digitalWrite(trig_pin, LOW);
  			delayMicroseconds(2);
  			digitalWrite(trig_pin, HIGH);
  			delayMicroseconds(10);
  			digitalWrite(trig_pin, LOW);
  			long duration = pulseIn(echo_pin, HIGH);
 			distance = duration / 58.2;
 			previousMillis = currentMillis;
		} 
	}
};

/*---------------Module Variables---------------------------*/
States_basic basic_state;
States_group group_state;

//finite state machine variables
unsigned long gameStartEvent;

//LAUNCH_STATE variables
uint8_t touchBackWall_LAUNCH;
unsigned long calibrateMoveBackEvent;
uint8_t touchLeftWall_LAUNCH;
unsigned long calibrateMoveLeftEvent;

// unsigned long moveBackwardEvent; // only used for hard coding test without ultrasonic sensor
Servo servo;
uint8_t touchBackWall_SHOOT;
uint8_t touchLeftWall_SHOOT;

// SHOOT_KINGS_LANDING_STATE variables
unsigned long loadStartEvent;
unsigned long shootStartEvent;
uint8_t safeToLeftWall_KINGS_LANDING;
uint8_t touchFrontWall_SHOOT;
unsigned long calibrateMoveForwardEvent;


//ultrasonic sensors
SuperSonicSensor sensor_front(MEASURE_DIST_PERIOD, US1_TRIG, US1_ECHO);
SuperSonicSensor sensor_back(MEASURE_DIST_PERIOD, US2_TRIG, US2_ECHO);
SuperSonicSensor sensor_left(MEASURE_DIST_PERIOD, US3_TRIG, US3_ECHO);
SuperSonicSensor sensor_right(MEASURE_DIST_PERIOD, US4_TRIG, US4_ECHO);
IntervalTimer printDistTimer;


/*---------------------Main Functions-----------------------*/
void setup() {

  // Serial used for testing functions
  Serial.begin(9600);
//   while(!Serial);
  Serial.println("Hello, world!");

  // pin setup

  //motors used to drive forward and backward
  pinMode(FB_D1, OUTPUT);
  pinMode(FB_D2, OUTPUT);
  pinMode(FB_EN, OUTPUT);

  //motors used to drive left and right
  pinMode(LR_D1, OUTPUT);
  pinMode(LR_D2, OUTPUT);
  pinMode(LR_EN, OUTPUT);

  //motor used to launch the wildfire
  pinMode(LA_EN, OUTPUT);
  pinMode(LA_D1, OUTPUT);
  pinMode(LA_D2, OUTPUT);

  // ultrasonic sensors' trigger pins
  pinMode(US1_TRIG, OUTPUT);
  pinMode(US2_TRIG, OUTPUT);
  pinMode(US3_TRIG, OUTPUT);
  pinMode(US4_TRIG, OUTPUT);

  // ultrasonic sensors' echo pins
  pinMode(US1_ECHO, INPUT);
  pinMode(US2_ECHO, INPUT);
  pinMode(US3_ECHO, INPUT);
  pinMode(US4_ECHO, INPUT);

  // First of First: stop all motors 
  handleStop();

  // initialize servo pin
  servo.attach(SERVO);
  servo.write(SERVO_OFF_ANGLE);

  // initialize digital pins for driving motors
  digitalWrite(FB_D1, HIGH);
  digitalWrite(FB_D2, LOW);
  digitalWrite(LR_D1, LOW);
  digitalWrite(LR_D2, HIGH);

  // initialize digital pins for shooting motors
  digitalWrite(LA_D1, LOW);
  digitalWrite(LA_D2, HIGH);

  // initialize competition timer (2 min 10 sec)
  gameStartEvent = millis();

  // initialize group state
  group_state = LAUNCH_STATE;
  // initialize the first basic state in LAUNCH_STATE
  basic_state = STATE_MOVE_BACKWARD;
  touchBackWall_LAUNCH = 0; // initialize
  handleMoveBackward();

  // print sensor distance timer initialized
  printDistTimer.begin(printDist, PRINT_DIST_PERIOD);

}

void loop() {
  //  put your main code here, to run repeatedly:
  checkGlobalEvents(); // only for key, updatemeasure, endgame

  // finite state machine
  switch (group_state) {
    case LAUNCH_STATE:
      fsmInLaunchState();
      if (TestForLaunchStateEnd()) RespToLaunchStateEnd();
      break;
    case SHOOT_KINGS_LANDING_STATE:
      fsmInShootKingsLandingState();
      if (TestForShootKingsLandingStateEnd()) RespToShootKingsLandingStateEnd();
      break;	
    case END_STATE:
      break;
    default:
      // unexpected state
      Serial.println("What is this group_state I do not even..."); 
  }
  
}




///////////////////////////////Robot Motion//////////////////////////////////
// handle robot motion
void handleMoveForward(void){
  digitalWrite(FB_D1, HIGH);
  digitalWrite(FB_D2, LOW);
  analogWrite(FB_EN, testMotorPWM);
  analogWrite(LR_EN, 0);
  analogWrite(LA_EN, 0);
}
void handleMoveBackward(void){
  digitalWrite(FB_D1, LOW);
  digitalWrite(FB_D2, HIGH);
  analogWrite(FB_EN, testMotorPWM);
  analogWrite(LR_EN, 0);
  analogWrite(LA_EN, 0);
}
void handleMoveLeft(void){
  digitalWrite(LR_D1, LOW);
  digitalWrite(LR_D2, HIGH);
  analogWrite(LR_EN, testMotorPWM); 
  analogWrite(FB_EN, 0);
  analogWrite(LA_EN, 0);
}
void handleMoveRight(void){
  digitalWrite(LR_D1, HIGH);
  digitalWrite(LR_D2, LOW);
  analogWrite(LR_EN, testMotorPWM);
  analogWrite(FB_EN, 0);
  analogWrite(LA_EN, 0);
}
void handleStop(void){
  analogWrite(FB_EN, 0);
  analogWrite(LR_EN, 0);
  analogWrite(LA_EN, 0);
}
/////////////////////////////////////////////////////////////////////////////



/////////////////////////////////LAUNCH_STATE/////////////////////////////////

// void fsmInLaunchState(void);
// uint8_t TestForLaunchStateEnd(void);
// void RespToLaunchStateEnd(void);

void fsmInLaunchState(void){
  // finite state machine in LAUNCH_STATE
  switch (basic_state) {

    case STATE_MOVE_BACKWARD:
      if (TestForHitBackWall() && !touchBackWall_LAUNCH) {
        calibrateMoveBackEvent = millis();
        touchBackWall_LAUNCH = 1; // set as high
      }
      if (touchBackWall_LAUNCH && (millis() - calibrateMoveBackEvent > CALIBRATION_PERIOD)){
        touchBackWall_LAUNCH = 0; // reset
        basic_state = STATE_MOVE_LEFT;
        touchLeftWall_LAUNCH = 0; // initialize
        handleMoveLeft();
      }
      break;

    case STATE_MOVE_LEFT:
      if (TestForHitLeftWall() && !touchLeftWall_LAUNCH) {
        calibrateMoveLeftEvent = millis();
        touchLeftWall_LAUNCH = 1; // set as high
      }
      break;

    default:
      // unexpected state
      Serial.println("What is this basic state in LAUNCH_STATE I do not even..."); 
  }
}

// event: LAUNCH_STATE end -> basic state is STATE_MOVE_LEFT and hit the left wall 
// 1 -> true, 0 -> false
uint8_t TestForLaunchStateEnd(void){
  if (basic_state == STATE_MOVE_LEFT && touchLeftWall_LAUNCH && (millis() - calibrateMoveLeftEvent > CALIBRATION_PERIOD)){
    touchLeftWall_LAUNCH = 0; // reset
    return 1;
  } else{
    return 0;
  }
}

// service: For test only. Right now after LAUNCH_STATE ends, go directly to END_STATE
void RespToLaunchStateEnd(void){
  group_state = SHOOT_KINGS_LANDING_STATE; // choose loop on SHOOT_KINGS_LANDING_STATE
  basic_state = STATE_LOAD;
  handleLoad();
}
/////////////////////////////////////////////////////////////////////////////



/////////////////////////SHOOT_KINGS_LANDING_STATE///////////////////////////

void handleLoad(void){
  handleStop(); // stop all motors
  loadStartEvent = millis(); // record loadStartEvent
}

void handleShoot(void){
  analogWrite(LA_EN, SHOOTING_MOTOR_PWM);
  servo.write(SERVO_OFF_ANGLE); // initially the servo is off to wait until the shooting motor is at high speed
}

void fsmInShootKingsLandingState(void){
  switch (basic_state) {
    case STATE_LOAD:
      if (millis() - loadStartEvent > LOADING_PERIOD) {
        basic_state = STATE_MOVE_RIGHT;
        handleMoveRight();
        safeToLeftWall_KINGS_LANDING = 0; // initialize
      }
      break;

    case STATE_MOVE_FORWARD:
      if (TestForHitFrontWall() && !touchFrontWall_SHOOT) {
        touchFrontWall_SHOOT = 1; // set as high
        calibrateMoveForwardEvent = millis();
      }
      if (touchFrontWall_SHOOT && (millis() - calibrateMoveForwardEvent > CALIBRATION_PERIOD)){
        touchFrontWall_SHOOT = 0; // reset
        basic_state = STATE_MOVE_RIGHT;
        handleMoveRight();
      }
      break;

    case STATE_MOVE_RIGHT:

      if (sensor_right.distance < KINGS_LANDING_TO_RIGHT_DISTANCE && safeToLeftWall_KINGS_LANDING) { // reach the position to shoot King's Landing
        basic_state = STATE_SHOOT;
        // safeToLeftWall_KINGS_LANDING = 0; // do not reset here, or it will run the if below. will initialize to 0 again later
        shootStartEvent = millis();
        handleStop(); // stop all motors first
        handleShoot(); // start shooting motor and turn off servo to wait until the shooting motor is at high speed
      }

      if (sensor_left.distance > SAFE_CLOSE_DISTANCE && !safeToLeftWall_KINGS_LANDING){
        safeToLeftWall_KINGS_LANDING = 1; // set as high
        touchFrontWall_SHOOT = 0; // initialize
        basic_state = STATE_MOVE_FORWARD;
        handleMoveForward();
      }
      break;	

    case STATE_SHOOT:
      // keep writing high and keep writing low to the servo should be fine
      if (millis() - shootStartEvent > SERVO_TURNED_ON_PERIOD && millis() - shootStartEvent < SHOOTING_PERIOD) {
        servo.write(SERVO_ON_ANGLE);
      }
      if (millis() - shootStartEvent > SHOOTING_PERIOD) {
        servo.write(SERVO_OFF_ANGLE);
        basic_state = STATE_MOVE_LEFT;
        safeToLeftWall_KINGS_LANDING = 0; // initialize (reset for moving right before as well)
        handleMoveLeft();
      }
      break;
	
    case STATE_MOVE_LEFT:
      if (TestForHitLeftWall() && !touchLeftWall_SHOOT && safeToLeftWall_KINGS_LANDING) {
        calibrateMoveLeftEvent = millis();
        touchLeftWall_SHOOT = 1; // set as high
      }

      if (sensor_left.distance < SAFE_CLOSE_DISTANCE && !safeToLeftWall_KINGS_LANDING) {
        safeToLeftWall_KINGS_LANDING = 1; // set as high
        basic_state = STATE_MOVE_BACKWARD;
        touchBackWall_SHOOT = 0; // initialize
        handleMoveBackward();
      }

      break;

    case STATE_MOVE_BACKWARD:

      if (TestForHitBackWall() && !touchBackWall_SHOOT) {
        calibrateMoveBackEvent = millis();
        touchBackWall_SHOOT = 1; // set as high
      }
      if (touchBackWall_SHOOT && (millis() - calibrateMoveBackEvent > CALIBRATION_PERIOD)){
        touchBackWall_SHOOT = 0; // reset
        basic_state = STATE_MOVE_LEFT;
        touchLeftWall_SHOOT = 0; // initialize. One thing to note is that safeToLeftWall_KINGS_LANDING is still 1
        handleMoveLeft();
      }
      break;

    default:
      // unexpected state
      Serial.println("What is this basic state in SHOOT_KINGS_LANDING_STATE I do not even..."); 
  }
}

uint8_t TestForShootKingsLandingStateEnd(void){
  // make sure that as long as the first is wrong, the second won't be checked, 
  // since moveBackwardEvent may not be assigned any value yet. 
  // or it is and we don't need to worry about it.
  if (basic_state == STATE_MOVE_LEFT && touchLeftWall_SHOOT && (millis() - calibrateMoveLeftEvent > CALIBRATION_PERIOD)){
    touchLeftWall_SHOOT = 0; // reset
	  safeToLeftWall_KINGS_LANDING = 0; // reset
    return 1;
  } else{
    return 0;
  }
}

void RespToShootKingsLandingStateEnd(void){
  group_state = SHOOT_KINGS_LANDING_STATE;
  basic_state = STATE_LOAD;
  handleLoad();
}


/////////////////////////////////////////////////////////////////////////////



/////////////////////////////////END_STATE///////////////////////////////////

void endGame(void){
  group_state = END_STATE;
  basic_state = STATE_STOP;
  handleStop();
}

/////////////////////////////////////////////////////////////////////////////

/////////////////////////////ultrasonic sensors//////////////////////////////
void printDist(){
	Serial.print(sensor_front.distance);
	Serial.print(", ");
	Serial.print(sensor_back.distance);
	Serial.print(", ");
	Serial.print(sensor_left.distance);
	Serial.print(", ");
	Serial.print(sensor_right.distance);
	Serial.println();
}

uint8_t TestForHitLeftWall(void){
  return (sensor_left.distance < HIT_WALL_DIST);
}
uint8_t TestForHitRightWall(void){
  return (sensor_right.distance < HIT_WALL_DIST);
}
uint8_t TestForHitFrontWall(void){
  return (sensor_front.distance < HIT_WALL_DIST);
}
uint8_t TestForHitBackWall(void){
  return (sensor_back.distance < HIT_WALL_DIST);
}
/////////////////////////////////////////////////////////////////////////////


///////////////////////////////Global Events/////////////////////////////////

// global events: Key (used for testing)
void checkGlobalEvents(void) {
  sensor_front.UpdateMeasure();
	sensor_back.UpdateMeasure();
	sensor_left.UpdateMeasure();
	sensor_right.UpdateMeasure();
  if (TestForKey()) RespToKey();
  if (millis() - gameStartEvent > GAME_PERIOD) endGame();
}

/////////////////////////////////////////////////////////////////////////////



//////////////////////////////////// Key ////////////////////////////////////

// Key event and response
uint8_t TestForKey(void) {
  uint8_t KeyEventOccurred;
  KeyEventOccurred = Serial.available();
  return KeyEventOccurred;
}
void RespToKey(void) {
  uint8_t theKey;
  theKey = Serial.read();
  // remote control of the robot
  if (theKey == 'p'){ // pause
    basic_state = STATE_STOP;
    Serial.println("Stop now..."); 
    handleStop();
  } else if (theKey == 'a'){
    basic_state = STATE_MOVE_LEFT;
    Serial.println("Move left now..."); 
    handleMoveLeft();
  } else if (theKey == 'd'){
    basic_state = STATE_MOVE_RIGHT;
    handleMoveRight();
    Serial.println("Move right now..."); 
  } else if (theKey == 'w'){
    basic_state = STATE_MOVE_FORWARD;
    handleMoveForward();
    Serial.println("Move forward now...");
  } else if (theKey == 's'){
    basic_state = STATE_MOVE_BACKWARD;
    handleMoveBackward();
    Serial.println("Move backward now...");
  } else{ // for any other key, just turn the moving direction clockwisely
      switch (basic_state) {
        case STATE_MOVE_FORWARD:
          basic_state = STATE_MOVE_RIGHT;
          handleMoveRight();
          Serial.println("Move right now..."); 
          break;
        case STATE_MOVE_BACKWARD:
          basic_state = STATE_MOVE_LEFT;
          handleMoveLeft();
          Serial.println("Move left now..."); 
          break;
        case STATE_MOVE_LEFT:
          basic_state = STATE_MOVE_FORWARD;
          handleMoveForward();
          Serial.println("Move forward now..."); 
          break;
        case STATE_MOVE_RIGHT:
          basic_state = STATE_MOVE_BACKWARD;
          handleMoveBackward();
          Serial.println("Move backward now..."); 
          break;
        case STATE_STOP:
          basic_state = STATE_MOVE_FORWARD;
          handleMoveForward();
          Serial.println("No need for changing directions..."); 
          break;
        default:
          // unexpected state
          Serial.println("No need for changing directions..."); 
      }
  }
}

//////////////////////////////////////////////////////////////////////////////////