// TOWER_HUNTER_ME210_PROJECT_2019 Functionality_Test v0.7
// Author: Team 24 (Zhongnan Hu, Zhe Huang, Arthur Ji, Lucas Zhou)
// Date: 03/07/19

// v0.1
// uploaded Driving Motor Test and Ultrasonic sensor Test

// v0.2
// uploaded Shooting Motor Test and Servo Test

// v0.3
// try to fix the bug in Ultrasonic Sensor Test

// v0.4
// Add shooting state test
// Try to fix the direction of the LR driving motors in the shooting state test
// Add Finite State Machine Test

// v0.5
// Fixed the bugs in shooting state test and finite state machine test
// Now shooting state test and finite state machine test work in a hard-coding sense
// May need to add calibration state and sensor code later

// v0.6
// Calibration Test

// v0.7
// Add king's landing state test





/*
///////////////////////////////// Driving Motor Test /////////////////////////////////
////////////////////////////// Ultrasonic Sensor Test 4 ////////////////////////////////
////////////////////////////// Ultrasonic Sensor Test 5 ////////////////////////////////
////////////////////////////// Shooting Motor Test ///////////////////////////////////
/////////////////////////////////// Servo Test ///////////////////////////////////////
////////////////////////////Shooting State Test///////////////////////////////////////
//////////////////////////// Finite State Machine Test ///////////////////////////////////////
///////////////////////////////Calibration Test///////////////////////////////////////
////////////////////////////ultrasonic sensor test 6////////////////////////////////////
//////////////////////////////King's Landing Test///////////////////////////////////
*/





///////////////////////////////// Driving Motor Test /////////////////////////////////
// #include <Arduino.h>

// /*---------------Module Defines-----------------------------*/
// #define FB_D1 1
// #define FB_D2 2
// #define FB_EN 3

// #define LR_D1 7
// #define LR_D2 8
// #define LR_EN 9

// // #define TEST_MOTOR_PWM 150
// #define TEST_MOTOR_PWM 255




// /*---------------Module Function Prototypes-----------------*/
// void checkGlobalEvents(void);
// unsigned char TestForKey(void);
// void RespToKey(void);

// void handleMoveForward(void);
// void handleMoveBackward(void);
// void handleMoveLeft(void);
// void handleMoveRight(void);
// void handleStop(void);

// /*---------------State Definitions--------------------------*/
// typedef enum {
//   STATE_STOP, STATE_MOVE_FORWARD, STATE_MOVE_BACKWARD, STATE_MOVE_LEFT, STATE_MOVE_RIGHT // shooting, loading state not added
// } States_t;

// /*---------------Module Variables---------------------------*/
// States_t state;

// /*---------------------Main Functions-----------------------*/
// void setup() {

//   // Serial used for testing functions
//   Serial.begin(9600);
//   while(!Serial);
//   Serial.println("Hello, world!");

//   // pin setup
//   pinMode(FB_D1, OUTPUT);
//   pinMode(FB_D2, OUTPUT);
//   pinMode(FB_EN, OUTPUT);

//   pinMode(LR_D1, OUTPUT);
//   pinMode(LR_D2, OUTPUT);
//   pinMode(LR_EN, OUTPUT);

//   // intial state: stop
//   state = STATE_STOP;
//   handleStop();

//   // initialize digital pins
//   digitalWrite(FB_D1, HIGH);
//   digitalWrite(FB_D2, LOW);
//   digitalWrite(LR_D1, HIGH);
//   digitalWrite(LR_D2, LOW);

// }

// void loop() {
//   //  put your main code here, to run repeatedly:
//   checkGlobalEvents(); // only for light off, LED, key

//   // finite state machine
//   switch (state) {
//     case STATE_MOVE_FORWARD:
//       // event: To be done
//       // service: To be done
//       break;
//     case STATE_MOVE_BACKWARD:
//       break;
//     case STATE_MOVE_LEFT:
//       break;
//     case STATE_MOVE_RIGHT:
//       break;
//     case STATE_STOP:
//       break;
//     default:
//       // unexpected state
//       Serial.println("What is this I do not even..."); 
//   }
  
// }


// // handle robot motion
// void handleMoveForward(void){
//   digitalWrite(FB_D1, HIGH);
//   digitalWrite(FB_D2, LOW);
//   analogWrite(FB_EN, TEST_MOTOR_PWM);
//   analogWrite(LR_EN, 0);
// }
// void handleMoveBackward(void){
//   digitalWrite(FB_D1, LOW);
//   digitalWrite(FB_D2, HIGH);
//   analogWrite(FB_EN, TEST_MOTOR_PWM);
//   analogWrite(LR_EN, 0);
// }

// void handleMoveLeft(void){
//   digitalWrite(LR_D1, HIGH);
//   digitalWrite(LR_D2, LOW);
//   analogWrite(LR_EN, TEST_MOTOR_PWM); 
//   analogWrite(FB_EN, 0);
// }
// void handleMoveRight(void){
//   digitalWrite(LR_D1, LOW);
//   digitalWrite(LR_D2, HIGH);
//   analogWrite(LR_EN, TEST_MOTOR_PWM);
//   analogWrite(FB_EN, 0);
// }

// void handleStop(void){
//   analogWrite(FB_EN, 0);
//   analogWrite(LR_EN, 0);
// }

// // global events: Key (used for testing)
// void checkGlobalEvents(void) {
//   if (TestForKey()) RespToKey(); 
// }

// // Key event and response
// uint8_t TestForKey(void) {
//   uint8_t KeyEventOccurred;
//   KeyEventOccurred = Serial.available();
//   return KeyEventOccurred;
// }
// void RespToKey(void) {
//   uint8_t theKey;
//   theKey = Serial.read();
//   // remote control of the robot
//   if (theKey == 'p'){ // pause
//     state = STATE_STOP;
//     Serial.println("Stop now..."); 
//     handleStop();
//   } else if (theKey == 'a'){
//     state = STATE_MOVE_LEFT;
//     Serial.println("Move left now..."); 
//     handleMoveLeft();
//   } else if (theKey == 'd'){
//     state = STATE_MOVE_RIGHT;
//     handleMoveRight();
//     Serial.println("Move right now..."); 
//   } else if (theKey == 'w'){
//     state = STATE_MOVE_FORWARD;
//     handleMoveForward();
//     Serial.println("Move forward now...");
//   } else if (theKey == 's'){
//     state = STATE_MOVE_BACKWARD;
//     handleMoveBackward();
//     Serial.println("Move backward now...");
//   } else{ // for any other key, just turn the moving direction clockwisely
//       switch (state) {
//         case STATE_MOVE_FORWARD:
//           state = STATE_MOVE_RIGHT;
//           handleMoveRight();
//           Serial.println("Move right now..."); 
//           break;
//         case STATE_MOVE_BACKWARD:
//           state = STATE_MOVE_LEFT;
//           handleMoveLeft();
//           Serial.println("Move left now..."); 
//           break;
//         case STATE_MOVE_LEFT:
//           state = STATE_MOVE_FORWARD;
//           handleMoveForward();
//           Serial.println("Move forward now..."); 
//           break;
//         case STATE_MOVE_RIGHT:
//           state = STATE_MOVE_BACKWARD;
//           handleMoveBackward();
//           Serial.println("Move backward now..."); 
//           break;
//         case STATE_STOP:
//           state = STATE_MOVE_FORWARD;
//           handleMoveForward();
//           Serial.println("No need for changing directions..."); 
//           break;
//         default:
//           // unexpected state
//           Serial.println("No need for changing directions..."); 
//       }
//   }
// }
//////////////////////////////////////////////////////////////////////////////////////



////////////////////////////// Ultrasonic Sensor Test 4 ////////////////////////////////
// #include <Arduino.h>
// int trigPin = 16;    // Trigger
// int echoPin = 21;    // Echo
// long duration, cm, inches;
 
// void setup() {
//   //Serial Port begin
//   Serial.begin (9600);
//   //Define inputs and outputs
//   pinMode(trigPin, OUTPUT);
//   pinMode(echoPin, INPUT);
// }
 
// void loop() {
//   // The sensor is triggered by a HIGH pulse of 10 or more microseconds.
//   // Give a short LOW pulse beforehand to ensure a clean HIGH pulse:
//   digitalWrite(trigPin, LOW);
//   delayMicroseconds(5);
//   digitalWrite(trigPin, HIGH);
//   delayMicroseconds(10);
//   digitalWrite(trigPin, LOW);
 
//   // Read the signal from the sensor: a HIGH pulse whose
//   // duration is the time (in microseconds) from the sending
//   // of the ping to the reception of its echo off of an object.
//   pinMode(echoPin, INPUT);
//   duration = pulseIn(echoPin, HIGH);
 
//   // Convert the time into a distance
//   cm = (duration/2) / 29.1;     // Divide by 29.1 or multiply by 0.0343
//   inches = (duration/2) / 74;   // Divide by 74 or multiply by 0.0135
  
//   Serial.print(inches);
//   Serial.print("in, ");
//   Serial.print(cm);
//   Serial.print("cm");
//   Serial.println();
  
//   delay(250);
// }
//////////////////////////////////////////////////////////////////////////////////////




////////////////////////////// Ultrasonic Sensor Test 5 ////////////////////////////////
// #include <Arduino.h>
// #include <Metro.h>

// #define US1_TRIG 16
// #define US1_ECHO 21
 
// // The sensor is triggered by a HIGH pulse of 10 or more microseconds.
// // Give a short LOW pulse beforehand to ensure a clean HIGH pulse.
// #define TRIG_LOW_PERIOD 5 // 5 microseconds
// #define TRIG_HIGH_PERIOD 10 // 10 microseconds
// #define PRINT_DIST_PERIOD 250 // print the distances every 250 milliseconds for Metro

// long duration1, cmF;
// int trigState = LOW;
// IntervalTimer trigHighTimer;
// IntervalTimer trigLowTimer;

// static Metro printDistTimer = Metro(PRINT_DIST_PERIOD);
// unsigned long pulseTimer;
// unsigned long pulseWidth;
// void trigOutputHigh();
// void trigOutputLow();

// int echoState = 0;
// int lastEchoState = 0;
// unsigned long lastEvent;
// unsigned long eventInterval = 10; // 10 milliseconds is way larger than the 10 microseconds pulse width

// void checkGlobalEvents(void);
// uint8_t TestPrintDistTimerExpired(void);
// void RespToPrintDistTimerExpired(void);
// void RespToEcho(void);

// void setup() {
//   // ultrasonic sensors' trigger pins
//   pinMode(US1_TRIG, OUTPUT);
//   // ultrasonic sensors' echo pins
//   pinMode(US1_ECHO, INPUT);
//   Serial.begin(9600);

//   lastEvent = millis(); // initialize lastEvent
// }

// void loop(){
//   checkGlobalEvents();
// }

// void checkGlobalEvents(void){
//   if (TestPrintDistTimerExpired()){
//     RespToPrintDistTimerExpired();
//   }
//   echoState = digitalRead(US1_ECHO);
//   if (echoState!=lastEchoState){
//     if (echoState == HIGH && millis() - lastEvent > eventInterval){
//       lastEvent = millis();
//       RespToEcho();
//     }
//   }
//   lastEchoState = echoState;
// }

// uint8_t TestPrintDistTimerExpired(void){
//   return (uint8_t) printDistTimer.check();
// }

// void RespToPrintDistTimerExpired(void){
//   printDistTimer.interval(PRINT_DIST_PERIOD);
//   printDistTimer.reset();
//   trigHighTimer.begin(trigOutputHigh, TRIG_LOW_PERIOD); // 5 microseconds
// }

// void RespToEcho(void){
//   noInterrupts();
//   pulseWidth = micros() - pulseTimer;
//   long cm = (pulseWidth/2) / 29.1;     // Divide by 29.1 or multiply by 0.0343
//   Serial.println(cm);
//   interrupts();
// }


// void trigOutputHigh(){
//   trigState = HIGH;
//   digitalWrite(US1_TRIG, trigState);
//   pulseTimer = micros();
//   trigHighTimer.end();
//   trigLowTimer.begin(trigOutputLow, TRIG_HIGH_PERIOD); // after TRIG_HIGH_PERIOD (10 micro seconds), set as low
// }

// void trigOutputLow(){
//   trigState = LOW;
//   digitalWrite(US1_TRIG, trigState);
//   trigLowTimer.end();
// }

//////////////////////////////////////////////////////////////////////////////////////



////////////////////////////// Shooting Motor Test ///////////////////////////////////
// #include <Arduino.h>

// /*---------------Module Defines-----------------------------*/
// #define LA_EN 10
// #define LA_D1 11
// #define LA_D2 12

// #define TEST_MOTOR_PWM 255


// /*---------------Module Function Prototypes-----------------*/
// void checkGlobalEvents(void);
// unsigned char TestForKey(void);
// void RespToKey(void);

// // void handleMoveForward(void);
// // void handleMoveBackward(void);
// // void handleMoveLeft(void);
// // void handleMoveRight(void);
// // void handleStop(void);

// void handleShoot(void);
// void handleStopShoot(void);
// void handleReverseDir(void);


// /*---------------State Definitions--------------------------*/
// typedef enum {
//   STATE_STOP, STATE_SHOOT // shooting, loading state not added
// } States_t;

// /*---------------Module Variables---------------------------*/
// States_t state;
// int dir = LOW;

// /*---------------------Main Functions-----------------------*/
// void setup() {

//   // Serial used for testing functions
//   Serial.begin(9600);
//   while(!Serial);
//   Serial.println("Hello, world!");

//   // pin setup

//   pinMode(LA_D1, OUTPUT);
//   pinMode(LA_D2, OUTPUT);
//   pinMode(LA_EN, OUTPUT);


//   // intial state: stop
//   state = STATE_STOP;
//   handleStopShoot();
//   // handleStop();

//   // initialize digital pins
//   digitalWrite(LA_D1, dir);
//   digitalWrite(LA_D2, !dir);
// }

// void loop() {
//   //  put your main code here, to run repeatedly:
//   checkGlobalEvents(); // only for light off, LED, key

//   // finite state machine
//   switch (state) {
//     case STATE_SHOOT:
//       break;
//     case STATE_STOP:
//       break;
//     default:
//       // unexpected state
//       Serial.println("What is this I do not even..."); 
//   }
// }


// // handle robot motion

// void handleStopShoot(void){
//   analogWrite(LA_EN, 0);
// }

// void handleShoot(void){
//   analogWrite(LA_EN, TEST_MOTOR_PWM);
// }

// void handleReverseDir(void){
//   dir = !dir;
//   digitalWrite(LA_D1, dir);
//   digitalWrite(LA_D2, !dir);
// }

// // void handleStop(void){
// //   analogWrite(FB_EN, 0);
// //   analogWrite(LR_EN, 0);
// // }



// // global events: Key (used for testing)
// void checkGlobalEvents(void) {
//   if (TestForKey()) RespToKey(); 
// }

// // Key event and response
// uint8_t TestForKey(void) {
//   uint8_t KeyEventOccurred;
//   KeyEventOccurred = Serial.available();
//   return KeyEventOccurred;
// }
// void RespToKey(void) {
//   uint8_t theKey;
//   theKey = Serial.read();
//   // remote control of the robot
//   if (theKey == 'r'){
//     handleReverseDir();
//   } else if (theKey == 's'){
//     switch (state) {
//       case STATE_SHOOT:
//         state = STATE_STOP;
//         handleStopShoot();
//         Serial.println("Stop shooting now...");
//         break;
//       case STATE_STOP:
//         state = STATE_SHOOT;
//         handleShoot();
//         Serial.println("Start shooting now..."); 
//         break;
//       default:
//         // unexpected state
//         Serial.println("No need for changing directions..."); 
//     }
//   }
// }

//////////////////////////////////////////////////////////////////////////////////////




/////////////////////////////////// Servo Test ///////////////////////////////////////

// // /*
// // Into Robotics
// // */
// #include <Arduino.h>
// #include <Servo.h> //add '<' and '>' before and after servo.h
// // // #include <Servo.h>
 
// int servoPin = 0;
 
// Servo servo;  
 
// int servoAngle = 0;   // servo position in degrees
 
// void setup()
// {
//   Serial.begin(9600);  
//   servo.attach(servoPin);
// }
// void loop()
// {
// //control the servo's direction and the position of the motor
// //150, 180

//    servo.write(180);      // Turn SG90 servo Left to 45 degrees
//    delay(1000);          // Wait 1 second
//    servo.write(180);      // Turn SG90 servo back to 90 degrees (center position)
//    delay(1000);          // Wait 1 second
//   //  servo.write(135);     // Turn SG90 servo Right to 135 degrees
//   //  delay(1000);          // Wait 1 second
//   //  servo.write(90);      // Turn SG90 servo back to 90 degrees (center position)
//   //  delay(1000);

// //end control the servo's direction and the position of the motor


// // //control the servo's speed  

// // //if you change the delay value (from example change 50 to 10), the speed of the servo changes
// //   for(servoAngle = 0; servoAngle < 180; servoAngle++)  //move the micro servo from 0 degrees to 180 degrees
// //   {                                  
// //     servo.write(servoAngle);              
// //     delay(50);                  
// //   }

// //   for(servoAngle = 180; servoAngle > 0; servoAngle--)  //now move back the micro servo from 0 degrees to 180 degrees
// //   {                                
// //     servo.write(servoAngle);          
// //     delay(10);      
// //   }
// //   //end control the servo's speed  

// }
//////////////////////////////////////////////////////////////////////////////////////


////////////////////////////Shooting State Test///////////////////////////////////////

// #include <Arduino.h>
// #include <Metro.h>
// #include <Servo.h>

// /*---------------Module Defines-----------------------------*/
// #define SERVO 0

// #define FB_D1 1
// #define FB_D2 2
// #define FB_EN 3

// #define LR_D1 7
// #define LR_D2 8
// #define LR_EN 9

// #define LA_EN 10
// #define LA_D1 11
// #define LA_D2 12

// #define US1_TRIG 13
// #define US2_TRIG 14
// #define US3_TRIG 15
// #define US4_TRIG 16

// #define US1_ECHO 18
// #define US2_ECHO 19
// #define US3_ECHO 20
// #define US4_ECHO 21

// // #define testMotorPWM 150
// #define testMotorPWM 255

// // The sensor is triggered by a HIGH pulse of 10 or more microseconds.
// // Give a short LOW pulse beforehand to ensure a clean HIGH pulse.
// #define TRIG_LOW_PERIOD 5 // 5 microseconds
// #define TRIG_HIGH_PERIOD 10 // 10 microseconds

// #define PRINT_DIST_PERIOD 250 // print the distances every 250 milliseconds

// // competition period 2 min 10 sec -> 130 sec -> 130,000 milliseconds
// #define GAME_PERIOD 130000

// //loading period: 5 sec -> 5,000 milliseconds
// #define LOADING_PERIOD 5000

// // the distance which is equivalent to the robot hitting the wall
// #define HIT_WALL_DIST 4 // 4 cm


// #define MOVING_FOWARD_PERIOD 3000 // for hard coding test only
// #define SHOOTING_PERIOD 8000 // after shooting period the servo will be turned off
// #define MOVING_BACKWARD_PERIOD 3000 // for hard coding test only
// #define SERVO_TURNED_ON_PERIOD 2000 // wait until shooting motor is at high speed

// #define SHOOTING_MOTOR_PWM 255
// #define SERVO_ON_ANGLE 150
// #define SERVO_OFF_ANGLE 180



// /*---------------Module Function Prototypes-----------------*/
// void checkGlobalEvents(void);
// unsigned char TestForKey(void);
// void RespToKey(void);

// void handleMoveForward(void);
// void handleMoveBackward(void);
// void handleMoveLeft(void);
// void handleMoveRight(void);
// void handleStop(void);

// // finite state machine service functions
// void endGame(void);

// void fsmInShootCasterlyRockState(void);
// uint8_t TestForShootCasterlyRockStateEnd(void);
// void RespToShootCasterlyRockStateEnd(void);

// //loading functions
// void handleLoad(void);


// /*---------------State Definitions--------------------------*/
// typedef enum {
//   STATE_STOP, STATE_MOVE_FORWARD, STATE_MOVE_BACKWARD, STATE_MOVE_LEFT, STATE_MOVE_RIGHT, STATE_LOAD, STATE_SHOOT // shooting, loading state not added
// } States_basic;

// typedef enum {
//   SHOOT_CASTERLY_ROCK_STATE, END_STATE // shooting, loading state not added
// } States_group;

// /*---------------Module Variables---------------------------*/
// States_basic basic_state;
// States_group group_state;

// //finite state machine variables
// unsigned long gameStartEvent;

// //load variables
// unsigned long loadStartEvent;
// unsigned long moveForwardEvent; // only used for hard coding test without ultrasonic sensor
// unsigned long shootStartEvent;
// unsigned long moveBackwardEvent; // only used for hard coding test without ultrasonic sensor
// Servo servo;


// /*---------------------Main Functions-----------------------*/
// void setup() {

//   // Serial used for testing functions
//   Serial.begin(9600);
//   while(!Serial);
//   Serial.println("Hello, world!");

//   // pin setup

//   //motors used to drive forward and backward
//   pinMode(FB_D1, OUTPUT);
//   pinMode(FB_D2, OUTPUT);
//   pinMode(FB_EN, OUTPUT);

//   //motors used to drive left and right
//   pinMode(LR_D1, OUTPUT);
//   pinMode(LR_D2, OUTPUT);
//   pinMode(LR_EN, OUTPUT);

//   //motor used to launch the wildfire
//   pinMode(LA_EN, OUTPUT);
//   pinMode(LA_D1, OUTPUT);
//   pinMode(LA_D2, OUTPUT);

//   // ultrasonic sensors' trigger pins
//   pinMode(US1_TRIG, OUTPUT);
//   pinMode(US2_TRIG, OUTPUT);
//   pinMode(US3_TRIG, OUTPUT);
//   pinMode(US4_TRIG, OUTPUT);

//   // ultrasonic sensors' echo pins
//   pinMode(US1_ECHO, INPUT);
//   pinMode(US2_ECHO, INPUT);
//   pinMode(US3_ECHO, INPUT);
//   pinMode(US4_ECHO, INPUT);

//   // First of First: stop all motors 
//   handleStop();

//   // initialize servo pin
//   servo.attach(SERVO);
//   servo.write(SERVO_OFF_ANGLE);

//   // initialize digital pins for driving motors
//   digitalWrite(FB_D1, HIGH);
//   digitalWrite(FB_D2, LOW);
//   digitalWrite(LR_D1, LOW);
//   digitalWrite(LR_D2, HIGH);

//   // initialize digital pins for shooting motors
//   digitalWrite(LA_D1, LOW);
//   digitalWrite(LA_D2, HIGH);

//   // initialize competition timer (2 min 10 sec)
//   gameStartEvent = millis();

//   // initialize group state (for test only, it is SHOOT_CASTERLY_ROCK_STATE)
//   group_state = SHOOT_CASTERLY_ROCK_STATE;
//   // initialize the first basic state in SHOOT_CASTERLY_ROCK_STATE
//   basic_state = STATE_LOAD;
//   handleLoad();


// }

// void loop() {
//   //  put your main code here, to run repeatedly:
//   checkGlobalEvents(); // only for light off, LED, key

//   // finite state machine
//   switch (group_state) {
//     case SHOOT_CASTERLY_ROCK_STATE:
//       fsmInShootCasterlyRockState();
//       if (TestForShootCasterlyRockStateEnd()) RespToShootCasterlyRockStateEnd();
//       break;
//     case END_STATE:
//       break;
//     default:
//       // unexpected state
//       Serial.println("What is this group_state I do not even..."); 
//   }
  
// }



// ///////////////////////////////Robot Motion//////////////////////////////////
// // handle robot motion
// void handleMoveForward(void){
//   digitalWrite(FB_D1, HIGH);
//   digitalWrite(FB_D2, LOW);
//   analogWrite(FB_EN, testMotorPWM);
//   analogWrite(LR_EN, 0);
//   analogWrite(LA_EN, 0);
// }
// void handleMoveBackward(void){
//   digitalWrite(FB_D1, LOW);
//   digitalWrite(FB_D2, HIGH);
//   analogWrite(FB_EN, testMotorPWM);
//   analogWrite(LR_EN, 0);
//   analogWrite(LA_EN, 0);
// }
// void handleMoveLeft(void){
//   digitalWrite(LR_D1, HIGH);
//   digitalWrite(LR_D2, LOW);
//   analogWrite(LR_EN, testMotorPWM); 
//   analogWrite(FB_EN, 0);
//   analogWrite(LA_EN, 0);
// }
// void handleMoveRight(void){
//   digitalWrite(LR_D1, LOW);
//   digitalWrite(LR_D2, HIGH);
//   analogWrite(LR_EN, testMotorPWM);
//   analogWrite(FB_EN, 0);
//   analogWrite(LA_EN, 0);
// }
// void handleStop(void){
//   analogWrite(FB_EN, 0);
//   analogWrite(LR_EN, 0);
//   analogWrite(LA_EN, 0);
// }
// /////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////LOAD_STATE//////////////////////////////////
// void handleLoad(void){
//   handleStop(); // stop all motors
//   loadStartEvent = millis(); // record loadStartEvent
// }

// void handleShoot(void){
//   analogWrite(LA_EN, SHOOTING_MOTOR_PWM);
//   servo.write(SERVO_OFF_ANGLE); // initially the servo is off to wait until the shooting motor is at high speed
// }

// // finite state machine in SHOOT_CASTERLY_ROCK_STATE
// void fsmInShootCasterlyRockState(void){
//   switch (basic_state) {
//     case STATE_LOAD:
//       if (millis() - loadStartEvent > LOADING_PERIOD) {
//         basic_state = STATE_MOVE_FORWARD;
//         moveForwardEvent = millis();
//         handleMoveForward();
//       }
//       break;
//     case STATE_MOVE_FORWARD:
//       if (millis() - moveForwardEvent > MOVING_FOWARD_PERIOD) {
//         basic_state = STATE_SHOOT;
//         shootStartEvent = millis();
//         handleStop(); // stop all motors first
//         handleShoot(); // start shooting motor and turn off servo to wait until the shooting motor is at high speed
//       }
//       break;
//     case STATE_SHOOT:
//       // keep writing high and keep writing low to the servo should be fine
//       if (millis() - shootStartEvent > SERVO_TURNED_ON_PERIOD && millis() - shootStartEvent < SHOOTING_PERIOD) {
//         servo.write(SERVO_ON_ANGLE);
//       }
//       if (millis() - shootStartEvent > SHOOTING_PERIOD) {
//         servo.write(SERVO_OFF_ANGLE);
//         basic_state = STATE_MOVE_BACKWARD;
//         moveBackwardEvent = millis();
//         handleMoveBackward();
//       }
//       break;
//     case STATE_MOVE_BACKWARD:
//       break;
//     default:
//       // unexpected state
//       Serial.println("What is this basic state in SHOOT_CASTERLY_ROCK_STATE I do not even..."); 
//   }
// }

// uint8_t TestForShootCasterlyRockStateEnd(void){
//   // make sure that as long as the first is wrong, the second won't be checked, 
//   // since moveBackwardEvent may not be assigned any value yet. 
//   // or it is and we don't need to worry about it.
//   if (basic_state == STATE_MOVE_BACKWARD && millis() - moveBackwardEvent > MOVING_BACKWARD_PERIOD) { 
//     return 1;
//   } else{
//     return 0;
//   }
// }

// void RespToShootCasterlyRockStateEnd(void){
//   group_state = SHOOT_CASTERLY_ROCK_STATE;
//   basic_state = STATE_LOAD;
//   handleLoad();
// }

// /////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////END_STATE///////////////////////////////////

// void endGame(void){
//   group_state = END_STATE;
//   basic_state = STATE_STOP;
//   handleStop();
// }

// /////////////////////////////////////////////////////////////////////////////



// ///////////////////////////////Global Events/////////////////////////////////

// // global events: Key (used for testing)
// void checkGlobalEvents(void) {
//   if (TestForKey()) RespToKey();
//   if (millis() - gameStartEvent > GAME_PERIOD) endGame();
// }

// /////////////////////////////////////////////////////////////////////////////



// //////////////////////////////////// Key ////////////////////////////////////

// // Key event and response
// uint8_t TestForKey(void) {
//   uint8_t KeyEventOccurred;
//   KeyEventOccurred = Serial.available();
//   return KeyEventOccurred;
// }
// void RespToKey(void) {
//   uint8_t theKey;
//   theKey = Serial.read();
//   // remote control of the robot
//   if (theKey == 'p'){ // pause
//     basic_state = STATE_STOP;
//     Serial.println("Stop now..."); 
//     handleStop();
//   } else if (theKey == 'a'){
//     basic_state = STATE_MOVE_LEFT;
//     Serial.println("Move left now..."); 
//     handleMoveLeft();
//   } else if (theKey == 'd'){
//     basic_state = STATE_MOVE_RIGHT;
//     handleMoveRight();
//     Serial.println("Move right now..."); 
//   } else if (theKey == 'w'){
//     basic_state = STATE_MOVE_FORWARD;
//     handleMoveForward();
//     Serial.println("Move forward now...");
//   } else if (theKey == 's'){
//     basic_state = STATE_MOVE_BACKWARD;
//     handleMoveBackward();
//     Serial.println("Move backward now...");
//   } else{ // for any other key, just turn the moving direction clockwisely
//       switch (basic_state) {
//         case STATE_MOVE_FORWARD:
//           basic_state = STATE_MOVE_RIGHT;
//           handleMoveRight();
//           Serial.println("Move right now..."); 
//           break;
//         case STATE_MOVE_BACKWARD:
//           basic_state = STATE_MOVE_LEFT;
//           handleMoveLeft();
//           Serial.println("Move left now..."); 
//           break;
//         case STATE_MOVE_LEFT:
//           basic_state = STATE_MOVE_FORWARD;
//           handleMoveForward();
//           Serial.println("Move forward now..."); 
//           break;
//         case STATE_MOVE_RIGHT:
//           basic_state = STATE_MOVE_BACKWARD;
//           handleMoveBackward();
//           Serial.println("Move backward now..."); 
//           break;
//         case STATE_STOP:
//           basic_state = STATE_MOVE_FORWARD;
//           handleMoveForward();
//           Serial.println("No need for changing directions..."); 
//           break;
//         default:
//           // unexpected state
//           Serial.println("No need for changing directions..."); 
//       }
//   }
// }
// /////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////////










//////////////////////////// Finite State Machine Test ///////////////////////////////////////

// #include <Arduino.h>
// #include <Metro.h>
// #include <Servo.h>

// /*---------------Module Defines-----------------------------*/
// #define SERVO 0

// #define FB_D1 1
// #define FB_D2 2
// #define FB_EN 3

// #define LR_D1 7
// #define LR_D2 8
// #define LR_EN 9

// #define LA_EN 10
// #define LA_D1 11
// #define LA_D2 12

// #define US1_TRIG 13
// #define US2_TRIG 14
// #define US3_TRIG 15
// #define US4_TRIG 16

// #define US1_ECHO 18
// #define US2_ECHO 19
// #define US3_ECHO 20
// #define US4_ECHO 21

// // #define testMotorPWM 150
// #define testMotorPWM 255

// // The sensor is triggered by a HIGH pulse of 10 or more microseconds.
// // Give a short LOW pulse beforehand to ensure a clean HIGH pulse.
// #define TRIG_LOW_PERIOD 5 // 5 microseconds
// #define TRIG_HIGH_PERIOD 10 // 10 microseconds

// #define PRINT_DIST_PERIOD 250 // print the distances every 250 milliseconds

// // competition period 2 min 10 sec -> 130 sec -> 130,000 milliseconds
// #define GAME_PERIOD 130000

// //loading period: 5 sec -> 5,000 milliseconds
// #define LOADING_PERIOD 5000

// // the distance which is equivalent to the robot hitting the wall
// #define HIT_WALL_DIST 4 // 4 cm


// #define MOVING_FOWARD_PERIOD 3000 // for hard coding test only
// #define SHOOTING_PERIOD 8000 // after shooting period the servo will be turned off
// #define MOVING_BACKWARD_PERIOD 3000 // for hard coding test only
// #define SERVO_TURNED_ON_PERIOD 1000 // wait until shooting motor is at high speed

// #define SHOOTING_MOTOR_PWM 255
// #define SERVO_ON_ANGLE 150
// #define SERVO_OFF_ANGLE 180

// #define MOVING_BACKWARD_PERIOD_LAUNCH 2000 // for hard coding test only
// #define MOVING_LEFT_PERIOD_LAUNCH 9000 // for hard coding test only

// #define DEBUG

// /*---------------Module Function Prototypes-----------------*/
// void checkGlobalEvents(void);
// unsigned char TestForKey(void);
// void RespToKey(void);

// void handleMoveForward(void);
// void handleMoveBackward(void);
// void handleMoveLeft(void);
// void handleMoveRight(void);
// void handleStop(void);

// // finite state machine service functions
// void endGame(void);

// void fsmInShootCasterlyRockState(void);
// uint8_t TestForShootCasterlyRockStateEnd(void);
// void RespToShootCasterlyRockStateEnd(void);

// void fsmInLaunchState(void);
// uint8_t TestForLaunchStateEnd(void);
// void RespToLaunchStateEnd(void);

// //loading functions
// void handleLoad(void);


// /*---------------State Definitions--------------------------*/
// typedef enum {
//   STATE_STOP, STATE_MOVE_FORWARD, STATE_MOVE_BACKWARD, STATE_MOVE_LEFT, STATE_MOVE_RIGHT, STATE_LOAD, STATE_SHOOT // shooting, loading state not added
// } States_basic;

// typedef enum {
//   LAUNCH_STATE, SHOOT_CASTERLY_ROCK_STATE, END_STATE
// } States_group;

// /*---------------Module Variables---------------------------*/
// States_basic basic_state;
// States_group group_state;

// //finite state machine variables
// unsigned long gameStartEvent;

// //LAUNCH_STATE variables
// unsigned long moveBackwardEvent_LAUNCH; // only used for hard coding test without ultrasonic sensor
// unsigned long moveLeftEvent_LAUNCH; // only used for hard coding test without ultrasonic sensor

// //LOAD_STATE variables
// unsigned long loadStartEvent;
// unsigned long moveForwardEvent; // only used for hard coding test without ultrasonic sensor
// unsigned long shootStartEvent;
// unsigned long moveBackwardEvent; // only used for hard coding test without ultrasonic sensor
// Servo servo;


// /*---------------------Main Functions-----------------------*/
// void setup() {

//   // Serial used for testing functions
//   Serial.begin(9600);
//   // while(!Serial);
//   Serial.println("Hello, world!");
//   // pin setup

//   //motors used to drive forward and backward
//   pinMode(FB_D1, OUTPUT);
//   pinMode(FB_D2, OUTPUT);
//   pinMode(FB_EN, OUTPUT);

//   //motors used to drive left and right
//   pinMode(LR_D1, OUTPUT);
//   pinMode(LR_D2, OUTPUT);
//   pinMode(LR_EN, OUTPUT);

//   //motor used to launch the wildfire
//   pinMode(LA_EN, OUTPUT);
//   pinMode(LA_D1, OUTPUT);
//   pinMode(LA_D2, OUTPUT);

//   // ultrasonic sensors' trigger pins
//   pinMode(US1_TRIG, OUTPUT);
//   pinMode(US2_TRIG, OUTPUT);
//   pinMode(US3_TRIG, OUTPUT);
//   pinMode(US4_TRIG, OUTPUT);

//   // ultrasonic sensors' echo pins
//   pinMode(US1_ECHO, INPUT);
//   pinMode(US2_ECHO, INPUT);
//   pinMode(US3_ECHO, INPUT);
//   pinMode(US4_ECHO, INPUT);

//   // First of First: stop all motors 
//   handleStop();

//   // initialize servo pin
//   servo.attach(SERVO);
//   servo.write(SERVO_OFF_ANGLE);

//   // initialize digital pins for driving motors
//   digitalWrite(FB_D1, HIGH);
//   digitalWrite(FB_D2, LOW);
//   digitalWrite(LR_D1, LOW);
//   digitalWrite(LR_D2, HIGH);

//   // initialize digital pins for shooting motors
//   digitalWrite(LA_D1, LOW);
//   digitalWrite(LA_D2, HIGH);

//   // initialize competition timer (2 min 10 sec)
//   gameStartEvent = millis();

//   // initialize group state
//   group_state = LAUNCH_STATE;
//   // initialize the first basic state in LAUNCH_STATE
//   basic_state = STATE_MOVE_BACKWARD;
//   moveBackwardEvent_LAUNCH = millis();
//   handleMoveBackward();

// }

// void loop() {
//   //  put your main code here, to run repeatedly:
//   checkGlobalEvents(); // only for light off, LED, key

//   // finite state machine
//   switch (group_state) {
//     case LAUNCH_STATE:
//       fsmInLaunchState();
//       if (TestForLaunchStateEnd()) RespToLaunchStateEnd();
//       break;
//     case SHOOT_CASTERLY_ROCK_STATE:
//       fsmInShootCasterlyRockState();
//       if (TestForShootCasterlyRockStateEnd()) RespToShootCasterlyRockStateEnd();
//       break;
//     case END_STATE:
//       break;
//     default:
//       // unexpected state

//       Serial.println("What is this group_state I do not even...");
//   }
  
// }




// ///////////////////////////////Robot Motion//////////////////////////////////
// // handle robot motion
// void handleMoveForward(void){
//   digitalWrite(FB_D1, HIGH);
//   digitalWrite(FB_D2, LOW);
//   analogWrite(FB_EN, testMotorPWM);
//   analogWrite(LR_EN, 0);
//   analogWrite(LA_EN, 0);
// }
// void handleMoveBackward(void){
//   digitalWrite(FB_D1, LOW);
//   digitalWrite(FB_D2, HIGH);
//   analogWrite(FB_EN, testMotorPWM);
//   analogWrite(LR_EN, 0);
//   analogWrite(LA_EN, 0);
// }
// void handleMoveLeft(void){
//   digitalWrite(LR_D1, LOW);
//   digitalWrite(LR_D2, HIGH);
//   analogWrite(LR_EN, testMotorPWM); 
//   analogWrite(FB_EN, 0);
//   analogWrite(LA_EN, 0);
// }
// void handleMoveRight(void){
//   digitalWrite(LR_D1, HIGH);
//   digitalWrite(LR_D2, LOW);
//   analogWrite(LR_EN, testMotorPWM);
//   analogWrite(FB_EN, 0);
//   analogWrite(LA_EN, 0);
// }
// void handleStop(void){
//   analogWrite(FB_EN, 0);
//   analogWrite(LR_EN, 0);
//   analogWrite(LA_EN, 0);
// }
// /////////////////////////////////////////////////////////////////////////////



// /////////////////////////////////LAUNCH_STATE/////////////////////////////////

// // void fsmInLaunchState(void);
// // uint8_t TestForLaunchStateEnd(void);
// // void RespToLaunchStateEnd(void);

// void fsmInLaunchState(void){
//   // finite state machine in LAUNCH_STATE
//   switch (basic_state) {
//     case STATE_MOVE_BACKWARD:
//       if (millis() - moveBackwardEvent_LAUNCH > MOVING_BACKWARD_PERIOD_LAUNCH) {
//         basic_state = STATE_MOVE_LEFT;
//         moveLeftEvent_LAUNCH = millis();
//         handleMoveLeft();
//       }
//       break;
//     case STATE_MOVE_LEFT:
//       break;
//     default:
//       // unexpected state

//       Serial.println("What is this basic state in LAUNCH_STATE I do not even..."); 

//   }
// }

// // event: LAUNCH_STATE end -> basic state is STATE_MOVE_LEFT and hit the left wall 
// // 1 -> true, 0 -> false
// uint8_t TestForLaunchStateEnd(void){
//   if (basic_state == STATE_MOVE_LEFT && millis() - moveLeftEvent_LAUNCH > MOVING_LEFT_PERIOD_LAUNCH) {
//     return 1;
//   } else{
//     return 0;
//   }
// }
// // service: For test only. Right now after LAUNCH_STATE ends, go directly to END_STATE
// void RespToLaunchStateEnd(void){
//   // endGame();
//   group_state = SHOOT_CASTERLY_ROCK_STATE;
//   basic_state = STATE_LOAD;
//   handleLoad();
// }


// /////////////////////////////////////////////////////////////////////////////



// //////////////////////SHOOT_CASTERLY_ROCK_STATE//////////////////////////////
// void handleLoad(void){
//   handleStop(); // stop all motors
//   loadStartEvent = millis(); // record loadStartEvent
// }

// void handleShoot(void){
//   analogWrite(LA_EN, SHOOTING_MOTOR_PWM);
//   servo.write(SERVO_OFF_ANGLE); // initially the servo is off to wait until the shooting motor is at high speed
// }

// // finite state machine in SHOOT_CASTERLY_ROCK_STATE
// void fsmInShootCasterlyRockState(void){
//   switch (basic_state) {
//     case STATE_LOAD:
//       if (millis() - loadStartEvent > LOADING_PERIOD) {
//         basic_state = STATE_MOVE_FORWARD;
//         moveForwardEvent = millis();
//         handleMoveForward();
//       }
//       break;
//     case STATE_MOVE_FORWARD:
//       if (millis() - moveForwardEvent > MOVING_FOWARD_PERIOD) {
//         basic_state = STATE_SHOOT;
//         shootStartEvent = millis();
//         handleStop(); // stop all motors first
//         handleShoot(); // start shooting motor and turn off servo to wait until the shooting motor is at high speed
//       }
//       break;
//     case STATE_SHOOT:
//       // keep writing high and keep writing low to the servo should be fine
//       if (millis() - shootStartEvent > SERVO_TURNED_ON_PERIOD && millis() - shootStartEvent < SHOOTING_PERIOD) {
//         servo.write(SERVO_ON_ANGLE);
//       }
//       if (millis() - shootStartEvent > SHOOTING_PERIOD) {
//         servo.write(SERVO_OFF_ANGLE);
//         basic_state = STATE_MOVE_BACKWARD;
//         moveBackwardEvent = millis();
//         handleMoveBackward();
//       }
//       break;
//     case STATE_MOVE_BACKWARD:
//       break;
//     default:
//       // unexpected state

//       Serial.println("What is this basic state in SHOOT_CASTERLY_ROCK_STATE I do not even..."); 
//   }
// }

// uint8_t TestForShootCasterlyRockStateEnd(void){
//   // make sure that as long as the first is wrong, the second won't be checked, 
//   // since moveBackwardEvent may not be assigned any value yet. 
//   // or it is and we don't need to worry about it.
//   if (basic_state == STATE_MOVE_BACKWARD && millis() - moveBackwardEvent > MOVING_BACKWARD_PERIOD) { 
//     return 1;
//   } else{
//     return 0;
//   }
// }

// void RespToShootCasterlyRockStateEnd(void){
//   group_state = SHOOT_CASTERLY_ROCK_STATE;
//   basic_state = STATE_LOAD;
//   handleLoad();
// }

// /////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////END_STATE///////////////////////////////////

// void endGame(void){
//   group_state = END_STATE;
//   basic_state = STATE_STOP;
//   handleStop();
// }

// /////////////////////////////////////////////////////////////////////////////



// ///////////////////////////////Global Events/////////////////////////////////

// // global events: Key (used for testing)
// void checkGlobalEvents(void) {
//   if (TestForKey()) RespToKey();
//   if (millis() - gameStartEvent > GAME_PERIOD) endGame();
// }

// /////////////////////////////////////////////////////////////////////////////



// //////////////////////////////////// Key ////////////////////////////////////

// // Key event and response
// uint8_t TestForKey(void) {
//   uint8_t KeyEventOccurred;
//   KeyEventOccurred = Serial.available();
//   return KeyEventOccurred;
// }
// void RespToKey(void) {
//   uint8_t theKey;
//   theKey = Serial.read();
//   // remote control of the robot
//   if (theKey == 'p'){ // pause
//     basic_state = STATE_STOP;
//     Serial.println("Stop now..."); 
//     handleStop();
//   } else if (theKey == 'a'){
//     basic_state = STATE_MOVE_LEFT;
//     Serial.println("Move left now..."); 
//     handleMoveLeft();
//   } else if (theKey == 'd'){
//     basic_state = STATE_MOVE_RIGHT;
//     handleMoveRight();
//     Serial.println("Move right now..."); 
//   } else if (theKey == 'w'){
//     basic_state = STATE_MOVE_FORWARD;
//     handleMoveForward();
//     Serial.println("Move forward now...");
//   } else if (theKey == 's'){
//     basic_state = STATE_MOVE_BACKWARD;
//     handleMoveBackward();
//     Serial.println("Move backward now...");
//   } else{ // for any other key, just turn the moving direction clockwisely
//       switch (basic_state) {
//         case STATE_MOVE_FORWARD:
//           basic_state = STATE_MOVE_RIGHT;
//           handleMoveRight();
//           Serial.println("Move right now..."); 
//           break;
//         case STATE_MOVE_BACKWARD:
//           basic_state = STATE_MOVE_LEFT;
//           handleMoveLeft();
//           Serial.println("Move left now..."); 
//           break;
//         case STATE_MOVE_LEFT:
//           basic_state = STATE_MOVE_FORWARD;
//           handleMoveForward();
//           Serial.println("Move forward now..."); 
//           break;
//         case STATE_MOVE_RIGHT:
//           basic_state = STATE_MOVE_BACKWARD;
//           handleMoveBackward();
//           Serial.println("Move backward now..."); 
//           break;
//         case STATE_STOP:
//           basic_state = STATE_MOVE_FORWARD;
//           handleMoveForward();
//           Serial.println("No need for changing directions..."); 
//           break;
//         default:
//           // unexpected state
//           Serial.println("No need for changing directions..."); 
//       }
//   }
// }

/////////////////////////////////////////////////////////////////////////////




//////////////////////////////////////////////////////////////////////////////////////






///////////////////////////////Calibration Test///////////////////////////////////////

// #include <Arduino.h>
// #include <Metro.h>
// #include <Servo.h>

// /*---------------Module Defines-----------------------------*/
// #define SERVO 0

// #define FB_D1 1
// #define FB_D2 2
// #define FB_EN 3

// #define LR_D1 7
// #define LR_D2 8
// #define LR_EN 9

// #define LA_EN 10
// #define LA_D1 11
// #define LA_D2 12

// #define US1_TRIG 13
// #define US2_TRIG 14
// #define US3_TRIG 15
// #define US4_TRIG 16

// #define US1_ECHO 18
// #define US2_ECHO 19
// #define US3_ECHO 20
// #define US4_ECHO 21

// // #define testMotorPWM 150
// #define testMotorPWM 255

// // The sensor is triggered by a HIGH pulse of 10 or more microseconds.
// // Give a short LOW pulse beforehand to ensure a clean HIGH pulse.
// #define TRIG_LOW_PERIOD 5 // 5 microseconds
// #define TRIG_HIGH_PERIOD 10 // 10 microseconds
// #define PRINT_DIST_PERIOD 250000 // 500000 microseconds -> 0.5 s
// #define MEASURE_DIST_PERIOD 250 // print the distances every 250 milliseconds

// // competition period 2 min 10 sec -> 130 sec -> 130,000 milliseconds
// #define GAME_PERIOD 130000

// //loading period: 5 sec -> 5,000 milliseconds
// #define LOADING_PERIOD 5000

// // the distance which is equivalent to the robot hitting the wall
// #define HIT_WALL_DIST 5 // 5 cm


// #define MOVING_FOWARD_PERIOD 3000 // for hard coding test only
// #define SHOOTING_PERIOD 8000 // after shooting period the servo will be turned off
// #define MOVING_BACKWARD_PERIOD 3000 // for hard coding test only
// #define SERVO_TURNED_ON_PERIOD 1000 // wait until shooting motor is at high speed

// #define SHOOTING_MOTOR_PWM 255
// #define SERVO_ON_ANGLE 150
// #define SERVO_OFF_ANGLE 180

// #define MOVING_BACKWARD_PERIOD_LAUNCH 2000 // for hard coding test only
// #define MOVING_LEFT_PERIOD_LAUNCH 9000 // for hard coding test only

// #define CALIBRATION_PERIOD 2000 // move for an extra time after touching the wall

// /*---------------Module Function Prototypes-----------------*/
// void checkGlobalEvents(void);
// unsigned char TestForKey(void);
// void RespToKey(void);

// void handleMoveForward(void);
// void handleMoveBackward(void);
// void handleMoveLeft(void);
// void handleMoveRight(void);
// void handleStop(void);

// // finite state machine service functions
// void endGame(void);

// void fsmInShootCasterlyRockState(void);
// uint8_t TestForShootCasterlyRockStateEnd(void);
// void RespToShootCasterlyRockStateEnd(void);

// void fsmInLaunchState(void);
// uint8_t TestForLaunchStateEnd(void);
// void RespToLaunchStateEnd(void);

// //loading functions
// void handleLoad(void);

// // test for hitting walls
// uint8_t TestForHitLeftWall(void);
// uint8_t TestForHitRightWall(void);
// uint8_t TestForHitFrontWall(void);
// uint8_t TestForHitBackWall(void);

// //ultrasonic sensors
// void printDist(void);

// /*---------------State Definitions--------------------------*/
// typedef enum {
//   STATE_STOP, STATE_MOVE_FORWARD, STATE_MOVE_BACKWARD, STATE_MOVE_LEFT, STATE_MOVE_RIGHT, STATE_LOAD, STATE_SHOOT // shooting, loading state not added
// } States_basic;

// typedef enum {
//   LAUNCH_STATE, SHOOT_CASTERLY_ROCK_STATE, END_STATE
// } States_group;


// class SuperSonicSensor
// {
// 	unsigned long measure_interval;
// 	int trig_pin;
// 	int echo_pin;

// 	unsigned long previousMillis;

// public:
// 	SuperSonicSensor(unsigned long interval, int trig, int echo){
// 		measure_interval = interval;
// 		trig_pin = trig;
// 		echo_pin = echo;
// 		pinMode(trig_pin, OUTPUT);
// 		pinMode(echo_pin, INPUT);

// 		previousMillis = 0;
// 	}

//   	long distance;

// 	void UpdateMeasure(){
// 		unsigned long currentMillis = millis();
// 		if (currentMillis - previousMillis >= measure_interval){
// 			digitalWrite(trig_pin, LOW);
//   			delayMicroseconds(2);
//   			digitalWrite(trig_pin, HIGH);
//   			delayMicroseconds(10);
//   			digitalWrite(trig_pin, LOW);
//   			long duration = pulseIn(echo_pin, HIGH);
//  			distance = duration / 58.2;
//  			previousMillis = currentMillis;
// 		} 
// 	}
// };

// /*---------------Module Variables---------------------------*/
// States_basic basic_state;
// States_group group_state;

// //finite state machine variables
// unsigned long gameStartEvent;

// //LAUNCH_STATE variables
// uint8_t touchBackWall_LAUNCH;
// unsigned long calibrateMoveBackEvent;
// uint8_t touchLeftWall_LAUNCH;
// unsigned long calibrateMoveLeftEvent;

// //LOAD_STATE variables
// unsigned long loadStartEvent;
// unsigned long moveForwardEvent; // only used for hard coding test without ultrasonic sensor
// unsigned long shootStartEvent;
// unsigned long moveBackwardEvent; // only used for hard coding test without ultrasonic sensor
// Servo servo;
// uint8_t touchBackWall_SHOOT;
// uint8_t touchLeftWall_SHOOT;

// //ultrasonic sensors
// SuperSonicSensor sensor_front(MEASURE_DIST_PERIOD, US1_TRIG, US1_ECHO);
// SuperSonicSensor sensor_back(MEASURE_DIST_PERIOD, US2_TRIG, US2_ECHO);
// SuperSonicSensor sensor_left(MEASURE_DIST_PERIOD, US3_TRIG, US3_ECHO);
// SuperSonicSensor sensor_right(MEASURE_DIST_PERIOD, US4_TRIG, US4_ECHO);
// IntervalTimer printDistTimer;


// /*---------------------Main Functions-----------------------*/
// void setup() {

//   // Serial used for testing functions
//   Serial.begin(9600);
// //   while(!Serial);
//   Serial.println("Hello, world!");

//   // pin setup

//   //motors used to drive forward and backward
//   pinMode(FB_D1, OUTPUT);
//   pinMode(FB_D2, OUTPUT);
//   pinMode(FB_EN, OUTPUT);

//   //motors used to drive left and right
//   pinMode(LR_D1, OUTPUT);
//   pinMode(LR_D2, OUTPUT);
//   pinMode(LR_EN, OUTPUT);

//   //motor used to launch the wildfire
//   pinMode(LA_EN, OUTPUT);
//   pinMode(LA_D1, OUTPUT);
//   pinMode(LA_D2, OUTPUT);

//   // ultrasonic sensors' trigger pins
//   pinMode(US1_TRIG, OUTPUT);
//   pinMode(US2_TRIG, OUTPUT);
//   pinMode(US3_TRIG, OUTPUT);
//   pinMode(US4_TRIG, OUTPUT);

//   // ultrasonic sensors' echo pins
//   pinMode(US1_ECHO, INPUT);
//   pinMode(US2_ECHO, INPUT);
//   pinMode(US3_ECHO, INPUT);
//   pinMode(US4_ECHO, INPUT);

//   // First of First: stop all motors 
//   handleStop();

//   // initialize servo pin
//   servo.attach(SERVO);
//   servo.write(SERVO_OFF_ANGLE);

//   // initialize digital pins for driving motors
//   digitalWrite(FB_D1, HIGH);
//   digitalWrite(FB_D2, LOW);
//   digitalWrite(LR_D1, LOW);
//   digitalWrite(LR_D2, HIGH);

//   // initialize digital pins for shooting motors
//   digitalWrite(LA_D1, LOW);
//   digitalWrite(LA_D2, HIGH);

//   // initialize competition timer (2 min 10 sec)
//   gameStartEvent = millis();

//   // initialize group state
//   group_state = LAUNCH_STATE;
//   // initialize the first basic state in LAUNCH_STATE
//   basic_state = STATE_MOVE_BACKWARD;
//   touchBackWall_LAUNCH = 0;
//   handleMoveBackward();

//   // print sensor distance timer initialized
//   printDistTimer.begin(printDist, PRINT_DIST_PERIOD);

// }

// void loop() {
//   //  put your main code here, to run repeatedly:
//   checkGlobalEvents(); // only for light off, LED, key

//   // finite state machine
//   switch (group_state) {
//     case LAUNCH_STATE:
//       fsmInLaunchState();
//       if (TestForLaunchStateEnd()) RespToLaunchStateEnd();
//       break;
//     case SHOOT_CASTERLY_ROCK_STATE:
//       fsmInShootCasterlyRockState();
//       if (TestForShootCasterlyRockStateEnd()) RespToShootCasterlyRockStateEnd();
//       break;
//     case END_STATE:
//       break;
//     default:
//       // unexpected state
//       Serial.println("What is this group_state I do not even..."); 
//   }
  
// }




// ///////////////////////////////Robot Motion//////////////////////////////////
// // handle robot motion
// void handleMoveForward(void){
//   digitalWrite(FB_D1, HIGH);
//   digitalWrite(FB_D2, LOW);
//   analogWrite(FB_EN, testMotorPWM);
//   analogWrite(LR_EN, 0);
//   analogWrite(LA_EN, 0);
// }
// void handleMoveBackward(void){
//   digitalWrite(FB_D1, LOW);
//   digitalWrite(FB_D2, HIGH);
//   analogWrite(FB_EN, testMotorPWM);
//   analogWrite(LR_EN, 0);
//   analogWrite(LA_EN, 0);
// }
// void handleMoveLeft(void){
//   digitalWrite(LR_D1, LOW);
//   digitalWrite(LR_D2, HIGH);
//   analogWrite(LR_EN, testMotorPWM); 
//   analogWrite(FB_EN, 0);
//   analogWrite(LA_EN, 0);
// }
// void handleMoveRight(void){
//   digitalWrite(LR_D1, HIGH);
//   digitalWrite(LR_D2, LOW);
//   analogWrite(LR_EN, testMotorPWM);
//   analogWrite(FB_EN, 0);
//   analogWrite(LA_EN, 0);
// }
// void handleStop(void){
//   analogWrite(FB_EN, 0);
//   analogWrite(LR_EN, 0);
//   analogWrite(LA_EN, 0);
// }
// /////////////////////////////////////////////////////////////////////////////



// /////////////////////////////////LAUNCH_STATE/////////////////////////////////

// // void fsmInLaunchState(void);
// // uint8_t TestForLaunchStateEnd(void);
// // void RespToLaunchStateEnd(void);

// void fsmInLaunchState(void){
//   // finite state machine in LAUNCH_STATE
//   switch (basic_state) {
//     case STATE_MOVE_BACKWARD:
      
//       if (TestForHitBackWall() && !touchBackWall_LAUNCH) {
//         calibrateMoveBackEvent = millis();
//         touchBackWall_LAUNCH = 1;
//       }
//       if (touchBackWall_LAUNCH && (millis() - calibrateMoveBackEvent > CALIBRATION_PERIOD)){
//         touchBackWall_LAUNCH = 0;
//         basic_state = STATE_MOVE_LEFT;
//         touchLeftWall_LAUNCH = 0;
//         handleMoveLeft();
//       }
//       break;
//     case STATE_MOVE_LEFT:
//       if (TestForHitLeftWall() && !touchLeftWall_LAUNCH) {
//         calibrateMoveLeftEvent = millis();
//         touchLeftWall_LAUNCH = 1;
//       }
//       break;
//     default:
//       // unexpected state
//       Serial.println("What is this basic state in LAUNCH_STATE I do not even..."); 
//   }
// }

// // event: LAUNCH_STATE end -> basic state is STATE_MOVE_LEFT and hit the left wall 
// // 1 -> true, 0 -> false
// uint8_t TestForLaunchStateEnd(void){
//   if (basic_state == STATE_MOVE_LEFT && touchLeftWall_LAUNCH && (millis() - calibrateMoveLeftEvent > CALIBRATION_PERIOD)){
//     touchLeftWall_LAUNCH = 0;
//     return 1;
//   } else{
//     return 0;
//   }
// }

// // service: For test only. Right now after LAUNCH_STATE ends, go directly to END_STATE
// void RespToLaunchStateEnd(void){
//   // endGame();
//   group_state = SHOOT_CASTERLY_ROCK_STATE;
//   basic_state = STATE_LOAD;
//   handleLoad();
// }


// /////////////////////////////////////////////////////////////////////////////



// //////////////////////SHOOT_CASTERLY_ROCK_STATE//////////////////////////////
// void handleLoad(void){
//   handleStop(); // stop all motors
//   loadStartEvent = millis(); // record loadStartEvent
// }

// void handleShoot(void){
//   analogWrite(LA_EN, SHOOTING_MOTOR_PWM);
//   servo.write(SERVO_OFF_ANGLE); // initially the servo is off to wait until the shooting motor is at high speed
// }

// // finite state machine in SHOOT_CASTERLY_ROCK_STATE
// void fsmInShootCasterlyRockState(void){
//   switch (basic_state) {
//     case STATE_LOAD:
//       if (millis() - loadStartEvent > LOADING_PERIOD) {
//         basic_state = STATE_MOVE_FORWARD;
//         moveForwardEvent = millis();
//         handleMoveForward();
//       }
//       break;
//     case STATE_MOVE_FORWARD:
//       if (millis() - moveForwardEvent > MOVING_FOWARD_PERIOD) {
//         basic_state = STATE_SHOOT;
//         shootStartEvent = millis();
//         handleStop(); // stop all motors first
//         handleShoot(); // start shooting motor and turn off servo to wait until the shooting motor is at high speed
//       }
//       break;
//     case STATE_SHOOT:
//       // keep writing high and keep writing low to the servo should be fine
//       if (millis() - shootStartEvent > SERVO_TURNED_ON_PERIOD && millis() - shootStartEvent < SHOOTING_PERIOD) {
//         servo.write(SERVO_ON_ANGLE);
//       }
//       if (millis() - shootStartEvent > SHOOTING_PERIOD) {
//         servo.write(SERVO_OFF_ANGLE);
//         basic_state = STATE_MOVE_BACKWARD;
//         moveBackwardEvent = millis();
//         handleMoveBackward();
//       }
//       break;
//     case STATE_MOVE_BACKWARD:

//       if (TestForHitBackWall() && !touchBackWall_SHOOT) {
//         calibrateMoveBackEvent = millis();
//         touchBackWall_SHOOT = 1;
//       }
//       if (touchBackWall_SHOOT && (millis() - calibrateMoveBackEvent > CALIBRATION_PERIOD)){
//         touchBackWall_SHOOT = 0;
//         basic_state = STATE_MOVE_LEFT;
//         touchLeftWall_SHOOT = 0;
//         handleMoveLeft();
//       }
//       break;
//     case STATE_MOVE_LEFT:
//       if (TestForHitLeftWall() && !touchLeftWall_SHOOT) {
//         calibrateMoveLeftEvent = millis();
//         touchLeftWall_SHOOT = 1;
//       }
//     break;
//     default:
//       // unexpected state
//       Serial.println("What is this basic state in SHOOT_CASTERLY_ROCK_STATE I do not even..."); 
//   }
// }

// uint8_t TestForShootCasterlyRockStateEnd(void){
//   // make sure that as long as the first is wrong, the second won't be checked, 
//   // since moveBackwardEvent may not be assigned any value yet. 
//   // or it is and we don't need to worry about it.
//   if (basic_state == STATE_MOVE_LEFT && touchLeftWall_SHOOT && (millis() - calibrateMoveLeftEvent > CALIBRATION_PERIOD)){
//     touchLeftWall_SHOOT = 0;
//     return 1;
//   } else{
//     return 0;
//   }
// }

// void RespToShootCasterlyRockStateEnd(void){
//   group_state = SHOOT_CASTERLY_ROCK_STATE;
//   basic_state = STATE_LOAD;
//   handleLoad();
// }

// /////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////END_STATE///////////////////////////////////

// void endGame(void){
//   group_state = END_STATE;
//   basic_state = STATE_STOP;
//   handleStop();
// }

// /////////////////////////////////////////////////////////////////////////////

// /////////////////////////////ultrasonic sensors//////////////////////////////
// void printDist(){
// 	Serial.print(sensor_front.distance);
// 	Serial.print(", ");
// 	Serial.print(sensor_back.distance);
// 	Serial.print(", ");
// 	Serial.print(sensor_left.distance);
// 	Serial.print(", ");
// 	Serial.print(sensor_right.distance);
// 	Serial.println();
// }

// uint8_t TestForHitLeftWall(void){
//   return (sensor_left.distance < HIT_WALL_DIST);
// }
// uint8_t TestForHitRightWall(void){
//   return (sensor_right.distance < HIT_WALL_DIST);
// }
// uint8_t TestForHitFrontWall(void){
//   return (sensor_front.distance < HIT_WALL_DIST);
// }
// uint8_t TestForHitBackWall(void){
//   return (sensor_back.distance < HIT_WALL_DIST);
// }
// /////////////////////////////////////////////////////////////////////////////


// ///////////////////////////////Global Events/////////////////////////////////

// // global events: Key (used for testing)
// void checkGlobalEvents(void) {
//   sensor_front.UpdateMeasure();
// 	sensor_back.UpdateMeasure();
// 	sensor_left.UpdateMeasure();
// 	sensor_right.UpdateMeasure();
//   if (TestForKey()) RespToKey();
//   if (millis() - gameStartEvent > GAME_PERIOD) endGame();
// }

// /////////////////////////////////////////////////////////////////////////////



// //////////////////////////////////// Key ////////////////////////////////////

// // Key event and response
// uint8_t TestForKey(void) {
//   uint8_t KeyEventOccurred;
//   KeyEventOccurred = Serial.available();
//   return KeyEventOccurred;
// }
// void RespToKey(void) {
//   uint8_t theKey;
//   theKey = Serial.read();
//   // remote control of the robot
//   if (theKey == 'p'){ // pause
//     basic_state = STATE_STOP;
//     Serial.println("Stop now..."); 
//     handleStop();
//   } else if (theKey == 'a'){
//     basic_state = STATE_MOVE_LEFT;
//     Serial.println("Move left now..."); 
//     handleMoveLeft();
//   } else if (theKey == 'd'){
//     basic_state = STATE_MOVE_RIGHT;
//     handleMoveRight();
//     Serial.println("Move right now..."); 
//   } else if (theKey == 'w'){
//     basic_state = STATE_MOVE_FORWARD;
//     handleMoveForward();
//     Serial.println("Move forward now...");
//   } else if (theKey == 's'){
//     basic_state = STATE_MOVE_BACKWARD;
//     handleMoveBackward();
//     Serial.println("Move backward now...");
//   } else{ // for any other key, just turn the moving direction clockwisely
//       switch (basic_state) {
//         case STATE_MOVE_FORWARD:
//           basic_state = STATE_MOVE_RIGHT;
//           handleMoveRight();
//           Serial.println("Move right now..."); 
//           break;
//         case STATE_MOVE_BACKWARD:
//           basic_state = STATE_MOVE_LEFT;
//           handleMoveLeft();
//           Serial.println("Move left now..."); 
//           break;
//         case STATE_MOVE_LEFT:
//           basic_state = STATE_MOVE_FORWARD;
//           handleMoveForward();
//           Serial.println("Move forward now..."); 
//           break;
//         case STATE_MOVE_RIGHT:
//           basic_state = STATE_MOVE_BACKWARD;
//           handleMoveBackward();
//           Serial.println("Move backward now..."); 
//           break;
//         case STATE_STOP:
//           basic_state = STATE_MOVE_FORWARD;
//           handleMoveForward();
//           Serial.println("No need for changing directions..."); 
//           break;
//         default:
//           // unexpected state
//           Serial.println("No need for changing directions..."); 
//       }
//   }
// }

//////////////////////////////////////////////////////////////////////////////////







// ////////////////////////////ultrasonic sensor test 6////////////////////////////////////

// #include <Arduino.h>

// /*---------------Module Defines-----------------------------*/
// #define FB_D1 1
// #define FB_D2 2
// #define FB_EN 3

// #define LR_D1 7
// #define LR_D2 8
// #define LR_EN 9

// #define LA_EN 10
// #define LA_D1 11
// #define LA_D2 12

// #define US1_TRIG 13
// #define US2_TRIG 14
// #define US3_TRIG 15
// #define US4_TRIG 16

// #define US1_ECHO 18
// #define US2_ECHO 19
// #define US3_ECHO 20
// #define US4_ECHO 21

// // #define testMotorPWM 150
// #define testMotorPWM 255

// // The sensor is triggered by a HIGH pulse of 10 or more microseconds.
// // Give a short LOW pulse beforehand to ensure a clean HIGH pulse.
// #define TRIG_LOW_PERIOD 5 // 5 microseconds
// #define TRIG_HIGH_PERIOD 10 // 10 microseconds

// #define MEASURE_DIST_PERIOD 250 // measure the distances every 1000 milliseconds

// #define HIT_WALL_DIST 5

// IntervalTimer printDistTimer;
// void checkGlobalEvents(void);
// void printDist(void);
// void handleMoveForward(void);
// void handleMoveBackward(void);
// void handleMoveLeft(void);
// void handleMoveRight(void);
// void handleStop(void);

// typedef enum {
//   STATE_STOP, STATE_MOVE_FORWARD, STATE_MOVE_BACKWARD, STATE_MOVE_LEFT, STATE_MOVE_RIGHT // shooting, loading state not added
// } States_t;

// States_t state;
// States_t prev_state;

// class SuperSonicSensor
// {
// 	unsigned long measure_interval;
// 	int trig_pin;
// 	int echo_pin;

// 	unsigned long previousMillis;

// public:
// 	SuperSonicSensor(unsigned long interval, int trig, int echo){
// 		measure_interval = interval;
// 		trig_pin = trig;
// 		echo_pin = echo;
// 		pinMode(trig_pin, OUTPUT);
// 		pinMode(echo_pin, INPUT);

// 		previousMillis = 0;
// 	}

//   	long distance;

// 	void UpdateMeasure(){
// 		unsigned long currentMillis = millis();
// 		if (currentMillis - previousMillis >= measure_interval){
// 			digitalWrite(trig_pin, LOW);
//   			delayMicroseconds(2);
//   			digitalWrite(trig_pin, HIGH);
//   			delayMicroseconds(10);
//   			digitalWrite(trig_pin, LOW);
//   			long duration = pulseIn(echo_pin, HIGH);
//  			distance = duration / 58.2;
//  			previousMillis = currentMillis;
// 		} 
// 	}
// };

// SuperSonicSensor sensor_front(MEASURE_DIST_PERIOD, US1_TRIG, US1_ECHO);
// SuperSonicSensor sensor_back(MEASURE_DIST_PERIOD, US2_TRIG, US2_ECHO);
// SuperSonicSensor sensor_left(MEASURE_DIST_PERIOD, US3_TRIG, US3_ECHO);
// SuperSonicSensor sensor_right(MEASURE_DIST_PERIOD, US4_TRIG, US4_ECHO);

// void setup() {

//   // Serial used for testing functions
//   Serial.begin(9600);
//   while(!Serial);
//   Serial.println("Hello, world!");

//    //motors used to drive forward and backward
//   pinMode(FB_D1, OUTPUT);
//   pinMode(FB_D2, OUTPUT);
//   pinMode(FB_EN, OUTPUT);

//   //motors used to drive left and right
//   pinMode(LR_D1, OUTPUT);
//   pinMode(LR_D2, OUTPUT);
//   pinMode(LR_EN, OUTPUT);

//   //motor used to launch the wildfire
//   pinMode(LA_EN, OUTPUT);
//   pinMode(LA_D1, OUTPUT);
//   pinMode(LA_D2, OUTPUT);

//   printDistTimer.begin(printDist, 500000);
//   state = STATE_MOVE_BACKWARD;
//   // handleMoveBackward();
//   }

// void loop(){
// 	sensor_front.UpdateMeasure();
// 	sensor_back.UpdateMeasure();
// 	sensor_left.UpdateMeasure();
// 	sensor_right.UpdateMeasure();
// 	checkGlobalEvents();

// }

// void checkGlobalEvents(){
// 	// if (sensor_front.distance < HIT_WALL_DIST && sensor_left.distance < HIT_WALL_DIST) state = STATE_MOVE_RIGHT;
// 	// if (sensor_right.distance < HIT_WALL_DIST && sensor_front.distance < HIT_WALL_DIST) state = STATE_MOVE_BACKWARD;
// 	// if (sensor_back.distance < HIT_WALL_DIST && sensor_right.distance < HIT_WALL_DIST) state = STATE_MOVE_LEFT;
// 	// if (sensor_left.distance < HIT_WALL_DIST && sensor_back.distance < HIT_WALL_DIST) state = STATE_MOVE_FORWARD;
// }

// void printDist(){
// 	Serial.print(sensor_front.distance);
// 	Serial.print(", ");
// 	Serial.print(sensor_back.distance);
// 	Serial.print(", ");
// 	Serial.print(sensor_left.distance);
// 	Serial.print(", ");
// 	Serial.print(sensor_right.distance);
// 	Serial.println();
// }

// void handleMoveForward(void){
//   digitalWrite(FB_D1, HIGH);
//   digitalWrite(FB_D2, LOW);
//   analogWrite(FB_EN, testMotorPWM);
//   analogWrite(LR_EN, 0);
// }
// void handleMoveBackward(void){
//   digitalWrite(FB_D1, LOW);
//   digitalWrite(FB_D2, HIGH);
//   analogWrite(FB_EN, testMotorPWM);
//   analogWrite(LR_EN, 0);
// }
// void handleMoveLeft(void){
//   digitalWrite(LR_D1, LOW);
//   digitalWrite(LR_D2, HIGH);
//   analogWrite(LR_EN, testMotorPWM); 
//   analogWrite(FB_EN, 0);
// }
// void handleMoveRight(void){
//   digitalWrite(LR_D1, HIGH);
//   digitalWrite(LR_D2, LOW);
//   analogWrite(LR_EN, testMotorPWM);
//   analogWrite(FB_EN, 0);
// }
// void handleStop(void){
//   analogWrite(FB_EN, 0);
//   analogWrite(LR_EN, 0);
//   analogWrite(LA_EN, 0);
// }
////////////////////////////////////////////////////////////////////////////////////







//////////////////////////////King's Landing Test///////////////////////////////////

#include <Arduino.h>
#include <Metro.h>
#include <Servo.h>

/*---------------Module Defines-----------------------------*/
#define SERVO 0

#define FB_D1 1
#define FB_D2 2
#define FB_EN 3

#define LR_D1 7
#define LR_D2 8
#define LR_EN 9

#define LA_EN 10
#define LA_D1 11
#define LA_D2 12

#define US1_TRIG 13
#define US2_TRIG 14
#define US3_TRIG 15
#define US4_TRIG 16

#define US1_ECHO 18
#define US2_ECHO 19
#define US3_ECHO 20
#define US4_ECHO 21

// #define testMotorPWM 150
#define testMotorPWM 255

// The sensor is triggered by a HIGH pulse of 10 or more microseconds.
// Give a short LOW pulse beforehand to ensure a clean HIGH pulse.
#define TRIG_LOW_PERIOD 5 // 5 microseconds
#define TRIG_HIGH_PERIOD 10 // 10 microseconds
#define PRINT_DIST_PERIOD 250000 // 500000 microseconds -> 0.5 s
#define MEASURE_DIST_PERIOD 250 // print the distances every 250 milliseconds

// competition period 2 min 10 sec -> 130 sec -> 130,000 milliseconds
#define GAME_PERIOD 130000

//loading period: 4 sec -> 4,000 milliseconds
#define LOADING_PERIOD 4000

// the distance which is equivalent to the robot hitting the wall
#define HIT_WALL_DIST 5 // 5 cm


#define MOVING_FOWARD_PERIOD 3000 // for hard coding test only
#define SHOOTING_PERIOD 6000 // after shooting period the servo will be turned off
#define MOVING_BACKWARD_PERIOD 3000 // for hard coding test only
#define SERVO_TURNED_ON_PERIOD 2000 // wait until shooting motor is at high speed

#define SHOOTING_MOTOR_PWM 255
#define SERVO_ON_ANGLE 150
#define SERVO_OFF_ANGLE 180

#define MOVING_BACKWARD_PERIOD_LAUNCH 2000 // for hard coding test only
#define MOVING_LEFT_PERIOD_LAUNCH 9000 // for hard coding test only

#define CALIBRATION_PERIOD 2000 // move for an extra time after touching the wall

#define KINGS_LANDING_TO_RIGHT_DISTANCE 120 // 4ft -> 120 cm approximately
#define SAFE_CLOSE_DISTANCE 10 // 10cm, not hit the wall but close enough to the wall
/*---------------Module Function Prototypes-----------------*/
void checkGlobalEvents(void);
unsigned char TestForKey(void);
void RespToKey(void);

void handleMoveForward(void);
void handleMoveBackward(void);
void handleMoveLeft(void);
void handleMoveRight(void);
void handleStop(void);

// finite state machine service functions
void endGame(void);

void fsmInShootCasterlyRockState(void);
uint8_t TestForShootCasterlyRockStateEnd(void);
void RespToShootCasterlyRockStateEnd(void);

void fsmInLaunchState(void);
uint8_t TestForLaunchStateEnd(void);
void RespToLaunchStateEnd(void);

void fsmInShootKingsLandingState(void);
uint8_t TestForShootKingsLandingStateEnd(void);
void RespToShootKingsLandingStateEnd(void);

//loading functions
void handleLoad(void);

// test for hitting walls
uint8_t TestForHitLeftWall(void);
uint8_t TestForHitRightWall(void);
uint8_t TestForHitFrontWall(void);
uint8_t TestForHitBackWall(void);

//ultrasonic sensors
void printDist(void);

/*---------------State Definitions--------------------------*/
typedef enum {
  STATE_STOP, STATE_MOVE_FORWARD, STATE_MOVE_BACKWARD, STATE_MOVE_LEFT, STATE_MOVE_RIGHT, STATE_LOAD, STATE_SHOOT // shooting, loading state not added
} States_basic;

typedef enum {
  LAUNCH_STATE, SHOOT_CASTERLY_ROCK_STATE, SHOOT_KINGS_LANDING_STATE, END_STATE
} States_group;


class SuperSonicSensor
{
	unsigned long measure_interval;
	int trig_pin;
	int echo_pin;

	unsigned long previousMillis;

public:
	SuperSonicSensor(unsigned long interval, int trig, int echo){
		measure_interval = interval;
		trig_pin = trig;
		echo_pin = echo;
		pinMode(trig_pin, OUTPUT);
		pinMode(echo_pin, INPUT);

		previousMillis = 0;
	}

  	long distance;

	void UpdateMeasure(){
		unsigned long currentMillis = millis();
		if (currentMillis - previousMillis >= measure_interval){
			digitalWrite(trig_pin, LOW);
  			delayMicroseconds(2);
  			digitalWrite(trig_pin, HIGH);
  			delayMicroseconds(10);
  			digitalWrite(trig_pin, LOW);
  			long duration = pulseIn(echo_pin, HIGH);
 			distance = duration / 58.2;
 			previousMillis = currentMillis;
		} 
	}
};

/*---------------Module Variables---------------------------*/
States_basic basic_state;
States_group group_state;

//finite state machine variables
unsigned long gameStartEvent;

//LAUNCH_STATE variables
uint8_t touchBackWall_LAUNCH;
unsigned long calibrateMoveBackEvent;
uint8_t touchLeftWall_LAUNCH;
unsigned long calibrateMoveLeftEvent;

//SHOOT_CASTERLY_ROCK_STATE variables
unsigned long loadStartEvent;
unsigned long shootStartEvent;

// unsigned long moveBackwardEvent; // only used for hard coding test without ultrasonic sensor
Servo servo;
uint8_t touchBackWall_SHOOT;
uint8_t touchLeftWall_SHOOT;

// SHOOT_KINGS_LANDING_STATE variables
uint8_t safeToLeftWall_KINGS_LANDING;


//ultrasonic sensors
SuperSonicSensor sensor_front(MEASURE_DIST_PERIOD, US1_TRIG, US1_ECHO);
SuperSonicSensor sensor_back(MEASURE_DIST_PERIOD, US2_TRIG, US2_ECHO);
SuperSonicSensor sensor_left(MEASURE_DIST_PERIOD, US3_TRIG, US3_ECHO);
SuperSonicSensor sensor_right(MEASURE_DIST_PERIOD, US4_TRIG, US4_ECHO);
IntervalTimer printDistTimer;


/*---------------------Main Functions-----------------------*/
void setup() {

  // Serial used for testing functions
  Serial.begin(9600);
//   while(!Serial);
  Serial.println("Hello, world!");

  // pin setup

  //motors used to drive forward and backward
  pinMode(FB_D1, OUTPUT);
  pinMode(FB_D2, OUTPUT);
  pinMode(FB_EN, OUTPUT);

  //motors used to drive left and right
  pinMode(LR_D1, OUTPUT);
  pinMode(LR_D2, OUTPUT);
  pinMode(LR_EN, OUTPUT);

  //motor used to launch the wildfire
  pinMode(LA_EN, OUTPUT);
  pinMode(LA_D1, OUTPUT);
  pinMode(LA_D2, OUTPUT);

  // ultrasonic sensors' trigger pins
  pinMode(US1_TRIG, OUTPUT);
  pinMode(US2_TRIG, OUTPUT);
  pinMode(US3_TRIG, OUTPUT);
  pinMode(US4_TRIG, OUTPUT);

  // ultrasonic sensors' echo pins
  pinMode(US1_ECHO, INPUT);
  pinMode(US2_ECHO, INPUT);
  pinMode(US3_ECHO, INPUT);
  pinMode(US4_ECHO, INPUT);

  // First of First: stop all motors 
  handleStop();

  // initialize servo pin
  servo.attach(SERVO);
  servo.write(SERVO_OFF_ANGLE);

  // initialize digital pins for driving motors
  digitalWrite(FB_D1, HIGH);
  digitalWrite(FB_D2, LOW);
  digitalWrite(LR_D1, LOW);
  digitalWrite(LR_D2, HIGH);

  // initialize digital pins for shooting motors
  digitalWrite(LA_D1, LOW);
  digitalWrite(LA_D2, HIGH);

  // initialize competition timer (2 min 10 sec)
  gameStartEvent = millis();

  // initialize group state
  group_state = LAUNCH_STATE;
  // initialize the first basic state in LAUNCH_STATE
  basic_state = STATE_MOVE_BACKWARD;
  touchBackWall_LAUNCH = 0; // initialize
  handleMoveBackward();

  // print sensor distance timer initialized
  printDistTimer.begin(printDist, PRINT_DIST_PERIOD);

}

void loop() {
  //  put your main code here, to run repeatedly:
  checkGlobalEvents(); // only for key, updatemeasure, endgame

  // finite state machine
  switch (group_state) {
    case LAUNCH_STATE:
      fsmInLaunchState();
      if (TestForLaunchStateEnd()) RespToLaunchStateEnd();
      break;
    case SHOOT_CASTERLY_ROCK_STATE:
      fsmInShootCasterlyRockState();
      if (TestForShootCasterlyRockStateEnd()) RespToShootCasterlyRockStateEnd();
      break;
    case SHOOT_KINGS_LANDING_STATE:
      fsmInShootKingsLandingState();
      if (TestForShootKingsLandingStateEnd()) RespToShootKingsLandingStateEnd();
      break;	
    case END_STATE:
      break;
    default:
      // unexpected state
      Serial.println("What is this group_state I do not even..."); 
  }
  
}




///////////////////////////////Robot Motion//////////////////////////////////
// handle robot motion
void handleMoveForward(void){
  digitalWrite(FB_D1, HIGH);
  digitalWrite(FB_D2, LOW);
  analogWrite(FB_EN, testMotorPWM);
  analogWrite(LR_EN, 0);
  analogWrite(LA_EN, 0);
}
void handleMoveBackward(void){
  digitalWrite(FB_D1, LOW);
  digitalWrite(FB_D2, HIGH);
  analogWrite(FB_EN, testMotorPWM);
  analogWrite(LR_EN, 0);
  analogWrite(LA_EN, 0);
}
void handleMoveLeft(void){
  digitalWrite(LR_D1, LOW);
  digitalWrite(LR_D2, HIGH);
  analogWrite(LR_EN, testMotorPWM); 
  analogWrite(FB_EN, 0);
  analogWrite(LA_EN, 0);
}
void handleMoveRight(void){
  digitalWrite(LR_D1, HIGH);
  digitalWrite(LR_D2, LOW);
  analogWrite(LR_EN, testMotorPWM);
  analogWrite(FB_EN, 0);
  analogWrite(LA_EN, 0);
}
void handleStop(void){
  analogWrite(FB_EN, 0);
  analogWrite(LR_EN, 0);
  analogWrite(LA_EN, 0);
}
/////////////////////////////////////////////////////////////////////////////



/////////////////////////////////LAUNCH_STATE/////////////////////////////////

// void fsmInLaunchState(void);
// uint8_t TestForLaunchStateEnd(void);
// void RespToLaunchStateEnd(void);

void fsmInLaunchState(void){
  // finite state machine in LAUNCH_STATE
  switch (basic_state) {

    case STATE_MOVE_BACKWARD:
      if (TestForHitBackWall() && !touchBackWall_LAUNCH) {
        calibrateMoveBackEvent = millis();
        touchBackWall_LAUNCH = 1; // set as high
      }
      if (touchBackWall_LAUNCH && (millis() - calibrateMoveBackEvent > CALIBRATION_PERIOD)){
        touchBackWall_LAUNCH = 0; // reset
        basic_state = STATE_MOVE_LEFT;
        touchLeftWall_LAUNCH = 0; // initialize
        handleMoveLeft();
      }
      break;

    case STATE_MOVE_LEFT:
      if (TestForHitLeftWall() && !touchLeftWall_LAUNCH) {
        calibrateMoveLeftEvent = millis();
        touchLeftWall_LAUNCH = 1; // set as high
      }
      break;

    default:
      // unexpected state
      Serial.println("What is this basic state in LAUNCH_STATE I do not even..."); 
  }
}

// event: LAUNCH_STATE end -> basic state is STATE_MOVE_LEFT and hit the left wall 
// 1 -> true, 0 -> false
uint8_t TestForLaunchStateEnd(void){
  if (basic_state == STATE_MOVE_LEFT && touchLeftWall_LAUNCH && (millis() - calibrateMoveLeftEvent > CALIBRATION_PERIOD)){
    touchLeftWall_LAUNCH = 0; // reset
    return 1;
  } else{
    return 0;
  }
}

// service: For test only. Right now after LAUNCH_STATE ends, go directly to END_STATE
void RespToLaunchStateEnd(void){
//   group_state = SHOOT_CASTERLY_ROCK_STATE; // choose loop on SHOOT_CASTERLY_ROCK_STATE
  group_state = SHOOT_KINGS_LANDING_STATE; // choose loop on SHOOT_KINGS_LANDING_STATE
  basic_state = STATE_LOAD;
  handleLoad();
}


/////////////////////////////////////////////////////////////////////////////



//////////////////////SHOOT_CASTERLY_ROCK_STATE//////////////////////////////
void handleLoad(void){
  handleStop(); // stop all motors
  loadStartEvent = millis(); // record loadStartEvent
}

void handleShoot(void){
  analogWrite(LA_EN, SHOOTING_MOTOR_PWM);
  servo.write(SERVO_OFF_ANGLE); // initially the servo is off to wait until the shooting motor is at high speed
}

// finite state machine in SHOOT_CASTERLY_ROCK_STATE
void fsmInShootCasterlyRockState(void){
  switch (basic_state) {

    case STATE_LOAD:
      if (millis() - loadStartEvent > LOADING_PERIOD) {
        basic_state = STATE_MOVE_FORWARD;
        handleMoveForward();
      }
      break;

    case STATE_MOVE_FORWARD:
      if (TestForHitFrontWall()) {
        basic_state = STATE_SHOOT;
        shootStartEvent = millis();
        handleStop(); // stop all motors first
        handleShoot(); // start shooting motor and turn off servo to wait until the shooting motor is at high speed
      }
      break;

    case STATE_SHOOT:
      // keep writing high and keep writing low to the servo should be fine
      if (millis() - shootStartEvent > SERVO_TURNED_ON_PERIOD && millis() - shootStartEvent < SHOOTING_PERIOD) {
        servo.write(SERVO_ON_ANGLE);
      }
      if (millis() - shootStartEvent > SHOOTING_PERIOD) {
        servo.write(SERVO_OFF_ANGLE);
        basic_state = STATE_MOVE_BACKWARD;
        touchBackWall_SHOOT = 0; // initialize
        handleMoveBackward();
      }
      break;

    case STATE_MOVE_BACKWARD:

      if (TestForHitBackWall() && !touchBackWall_SHOOT) {
        calibrateMoveBackEvent = millis();
        touchBackWall_SHOOT = 1; // set as high
      }
      if (touchBackWall_SHOOT && (millis() - calibrateMoveBackEvent > CALIBRATION_PERIOD)){
        touchBackWall_SHOOT = 0; // reset
        basic_state = STATE_MOVE_LEFT;
        touchLeftWall_SHOOT = 0; // initialize
        handleMoveLeft();
      }
      break;

    case STATE_MOVE_LEFT:
      if (TestForHitLeftWall() && !touchLeftWall_SHOOT) {
        calibrateMoveLeftEvent = millis();
        touchLeftWall_SHOOT = 1; // set as high
      }
      break;
    default:
      // unexpected state
      Serial.println("What is this basic state in SHOOT_CASTERLY_ROCK_STATE I do not even..."); 
  }
}

uint8_t TestForShootCasterlyRockStateEnd(void){
  // make sure that as long as the first is wrong, the second won't be checked, 
  // since moveBackwardEvent may not be assigned any value yet. 
  // or it is and we don't need to worry about it.
  if (basic_state == STATE_MOVE_LEFT && touchLeftWall_SHOOT && (millis() - calibrateMoveLeftEvent > CALIBRATION_PERIOD)){
    touchLeftWall_SHOOT = 0; // reset
    return 1;
  } else{
    return 0;
  }
}

void RespToShootCasterlyRockStateEnd(void){
  group_state = SHOOT_CASTERLY_ROCK_STATE;
  basic_state = STATE_LOAD;
  handleLoad();
}

/////////////////////////////////////////////////////////////////////////////


/////////////////////////SHOOT_KINGS_LANDING_STATE///////////////////////////

// void handleLoad(void){
//   handleStop(); // stop all motors
//   loadStartEvent = millis(); // record loadStartEvent
// }

// void handleShoot(void){
//   analogWrite(LA_EN, SHOOTING_MOTOR_PWM);
//   servo.write(SERVO_OFF_ANGLE); // initially the servo is off to wait until the shooting motor is at high speed
// }

// finite state machine in SHOOT_CASTERLY_ROCK_STATE
void fsmInShootKingsLandingState(void){
  switch (basic_state) {
    case STATE_LOAD:
      if (millis() - loadStartEvent > LOADING_PERIOD) {
        basic_state = STATE_MOVE_FORWARD;
        handleMoveForward();
      }
      break;

    case STATE_MOVE_FORWARD:
      if (TestForHitFrontWall()) {
        basic_state = STATE_MOVE_RIGHT;
        handleMoveRight();
      }
      break;

    case STATE_MOVE_RIGHT:
      if (sensor_right.distance < KINGS_LANDING_TO_RIGHT_DISTANCE) { // reach the position to shoot King's Landing
        basic_state = STATE_SHOOT;
        shootStartEvent = millis();
        handleStop(); // stop all motors first
        handleShoot(); // start shooting motor and turn off servo to wait until the shooting motor is at high speed
      }
      break;	

    case STATE_SHOOT:
      // keep writing high and keep writing low to the servo should be fine
      if (millis() - shootStartEvent > SERVO_TURNED_ON_PERIOD && millis() - shootStartEvent < SHOOTING_PERIOD) {
        servo.write(SERVO_ON_ANGLE);
      }
      if (millis() - shootStartEvent > SHOOTING_PERIOD) {
        servo.write(SERVO_OFF_ANGLE);
        basic_state = STATE_MOVE_LEFT;
        safeToLeftWall_KINGS_LANDING = 0; // initialize
        handleMoveLeft();
      }
      break;
	
    case STATE_MOVE_LEFT:
      if (sensor_left.distance < SAFE_CLOSE_DISTANCE && !safeToLeftWall_KINGS_LANDING) {
        safeToLeftWall_KINGS_LANDING = 1; // set as high
        basic_state = STATE_MOVE_BACKWARD;
        touchBackWall_SHOOT = 0; // initialize
        handleMoveBackward();
      }
      if (TestForHitLeftWall() && !touchLeftWall_SHOOT) {
        calibrateMoveLeftEvent = millis();
        touchLeftWall_SHOOT = 1; // set as high
      }
      break;

    case STATE_MOVE_BACKWARD:

      if (TestForHitBackWall() && !touchBackWall_SHOOT) {
        calibrateMoveBackEvent = millis();
        touchBackWall_SHOOT = 1; // set as high
      }
      if (touchBackWall_SHOOT && (millis() - calibrateMoveBackEvent > CALIBRATION_PERIOD)){
        touchBackWall_SHOOT = 0; // reset
        basic_state = STATE_MOVE_LEFT;
        touchLeftWall_SHOOT = 0; // initialize. One thing to note is that safeToLeftWall_KINGS_LANDING is still 1
        handleMoveLeft();
      }
      break;
    // case STATE_MOVE_LEFT:
    //   if (TestForHitLeftWall() && !touchLeftWall_SHOOT) {
    //     calibrateMoveLeftEvent = millis();
    //     touchLeftWall_SHOOT = 1;
    //   }
    //   break;
    default:
      // unexpected state
      Serial.println("What is this basic state in SHOOT_KINGS_LANDING_STATE I do not even..."); 
  }
}

uint8_t TestForShootKingsLandingStateEnd(void){
  // make sure that as long as the first is wrong, the second won't be checked, 
  // since moveBackwardEvent may not be assigned any value yet. 
  // or it is and we don't need to worry about it.
  if (basic_state == STATE_MOVE_LEFT && touchLeftWall_SHOOT && (millis() - calibrateMoveLeftEvent > CALIBRATION_PERIOD)){
    touchLeftWall_SHOOT = 0; // reset
	  safeToLeftWall_KINGS_LANDING = 0; // reset
    return 1;
  } else{
    return 0;
  }
}

void RespToShootKingsLandingStateEnd(void){
  group_state = SHOOT_KINGS_LANDING_STATE;
  basic_state = STATE_LOAD;
  handleLoad();
}



/////////////////////////////////////////////////////////////////////////////



/////////////////////////////////END_STATE///////////////////////////////////

void endGame(void){
  group_state = END_STATE;
  basic_state = STATE_STOP;
  handleStop();
}

/////////////////////////////////////////////////////////////////////////////

/////////////////////////////ultrasonic sensors//////////////////////////////
void printDist(){
	Serial.print(sensor_front.distance);
	Serial.print(", ");
	Serial.print(sensor_back.distance);
	Serial.print(", ");
	Serial.print(sensor_left.distance);
	Serial.print(", ");
	Serial.print(sensor_right.distance);
	Serial.println();
}

uint8_t TestForHitLeftWall(void){
  return (sensor_left.distance < HIT_WALL_DIST);
}
uint8_t TestForHitRightWall(void){
  return (sensor_right.distance < HIT_WALL_DIST);
}
uint8_t TestForHitFrontWall(void){
  return (sensor_front.distance < HIT_WALL_DIST);
}
uint8_t TestForHitBackWall(void){
  return (sensor_back.distance < HIT_WALL_DIST);
}
/////////////////////////////////////////////////////////////////////////////


///////////////////////////////Global Events/////////////////////////////////

// global events: Key (used for testing)
void checkGlobalEvents(void) {
  sensor_front.UpdateMeasure();
	sensor_back.UpdateMeasure();
	sensor_left.UpdateMeasure();
	sensor_right.UpdateMeasure();
  if (TestForKey()) RespToKey();
  if (millis() - gameStartEvent > GAME_PERIOD) endGame();
}

/////////////////////////////////////////////////////////////////////////////



//////////////////////////////////// Key ////////////////////////////////////

// Key event and response
uint8_t TestForKey(void) {
  uint8_t KeyEventOccurred;
  KeyEventOccurred = Serial.available();
  return KeyEventOccurred;
}
void RespToKey(void) {
  uint8_t theKey;
  theKey = Serial.read();
  // remote control of the robot
  if (theKey == 'p'){ // pause
    basic_state = STATE_STOP;
    Serial.println("Stop now..."); 
    handleStop();
  } else if (theKey == 'a'){
    basic_state = STATE_MOVE_LEFT;
    Serial.println("Move left now..."); 
    handleMoveLeft();
  } else if (theKey == 'd'){
    basic_state = STATE_MOVE_RIGHT;
    handleMoveRight();
    Serial.println("Move right now..."); 
  } else if (theKey == 'w'){
    basic_state = STATE_MOVE_FORWARD;
    handleMoveForward();
    Serial.println("Move forward now...");
  } else if (theKey == 's'){
    basic_state = STATE_MOVE_BACKWARD;
    handleMoveBackward();
    Serial.println("Move backward now...");
  } else{ // for any other key, just turn the moving direction clockwisely
      switch (basic_state) {
        case STATE_MOVE_FORWARD:
          basic_state = STATE_MOVE_RIGHT;
          handleMoveRight();
          Serial.println("Move right now..."); 
          break;
        case STATE_MOVE_BACKWARD:
          basic_state = STATE_MOVE_LEFT;
          handleMoveLeft();
          Serial.println("Move left now..."); 
          break;
        case STATE_MOVE_LEFT:
          basic_state = STATE_MOVE_FORWARD;
          handleMoveForward();
          Serial.println("Move forward now..."); 
          break;
        case STATE_MOVE_RIGHT:
          basic_state = STATE_MOVE_BACKWARD;
          handleMoveBackward();
          Serial.println("Move backward now..."); 
          break;
        case STATE_STOP:
          basic_state = STATE_MOVE_FORWARD;
          handleMoveForward();
          Serial.println("No need for changing directions..."); 
          break;
        default:
          // unexpected state
          Serial.println("No need for changing directions..."); 
      }
  }
}

//////////////////////////////////////////////////////////////////////////////////